# TransitCare - Smart Public Transport Complaint Portal

Passengers report bus problems, track them with a unique complaint ID, and see them resolved. Transport authorities manage complaints, buses, routes and users from one admin dashboard. All statistics are calculated from MongoDB records (nothing is hardcoded).

**Stack:** React + Vite + Tailwind CSS + React Router | Node.js + Express | MongoDB + Mongoose | JWT + bcrypt | Leaflet + OpenStreetMap

## Features

| Area | What you get |
|---|---|
| Public | Home with live stats and live map, complaint tracking by ID (with status timeline), bus fleet, routes with stop lists and route maps, About, Contact (saved to DB) |
| Passenger | Register/login, dashboard with personal stats, submit complaint with map pin, edit/withdraw while Pending, search + filters + table/map views |
| Admin | Overview (stats, 14-day trend, categories, busiest routes, priorities, map), manage complaints (status, priority, remarks), CRUD for buses, routes, users, read contact messages |
| Security | bcrypt (cost 12), JWT, role-based authorization, ownership checks, validation, rate limiting, helmet, CORS allow-list, no secrets in frontend |

## Folder structure

```
TransitCare/
├── README.md
├── backend/
│   ├── .env.example
│   ├── package.json
│   ├── server.js                 # app wiring, security middleware, startup checks
│   ├── config/db.js              # MongoDB connection (MONGO_URI from env)
│   ├── models/                   # User, Bus, Route, Complaint, Message
│   ├── controllers/              # auth, complaint, bus, route, user, stats, message (+ crudFactory)
│   ├── routes/                   # Express routers + express-validator rules
│   ├── middleware/               # auth (JWT + roles), validate, error (centralised)
│   ├── utils/                    # ApiError, asyncHandler, token
│   └── scripts/
│       ├── seed.js               # demo data (dev only)
│       └── createAdmin.js        # initial admin (dev only)
└── frontend/
    ├── .env.example
    ├── package.json, vite.config.js, tailwind.config.js, postcss.config.js, index.html
    └── src/
        ├── main.jsx, App.jsx, index.css
        ├── api/client.js         # axios + token + error helper
        ├── context/AuthContext.jsx
        ├── hooks/useFetch.js
        ├── utils/constants.js
        ├── components/           # Navbar, Footer, layouts, ProtectedRoute, ui (badges, cards, modal...),
        │                         # ComplaintTable/Filters/Panel, ComplaintMap, LocationPicker, StatusModal...
        └── pages/                # Home, Login, Register, About, Contact, Track, Buses, Routes,
            │                     # Dashboard, ComplaintForm, ComplaintDetail
            └── admin/            # AdminOverview, AdminComplaints, AdminBuses, AdminRoutes, AdminUsers, AdminMessages
```

## Prerequisites

- Node.js 18 or newer
- MongoDB 6+ (local install, Docker, or a free MongoDB Atlas cluster)

## 1. Start MongoDB

Pick one:

```bash
# Docker (easiest, data persists in a named volume)
docker run -d --name transitcare-mongo -p 27017:27017 -v transitcare-data:/data/db mongo:7

# macOS (Homebrew)
brew services start mongodb-community

# Ubuntu / Debian (after installing mongodb-org)
sudo systemctl start mongod

# Windows: start the "MongoDB Server" service, or run mongod.exe
```

Or use **MongoDB Atlas**: create a free cluster, add a database user, allow your IP, and copy the connection string into `MONGO_URI`.

## 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env        # Windows: copy .env.example .env
```

Edit `backend/.env`:

| Variable | Purpose |
|---|---|
| `MONGO_URI` | `mongodb://127.0.0.1:27017/transitcare` locally, or your Atlas string |
| `JWT_SECRET` | **Required**, 24+ chars. Generate: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `JWT_EXPIRES_IN` | Token lifetime, default `7d` |
| `CLIENT_URL` | Allowed browser origin(s), comma separated. Default `http://localhost:5173` |
| `PORT` | API port, default `5000` |
| `ADMIN_NAME/EMAIL/PASSWORD` | Used only by the dev scripts below |

The server refuses to start if `JWT_SECRET` is missing, short, or still the placeholder.

### Load demo data

```bash
npm run seed
```

This **wipes** users/buses/routes/complaints/messages and creates: 1 admin, 6 passengers, 6 routes (Hyderabad stops with coordinates), 18 buses and 64 complaints spread over the last 45 days with realistic statuses, remarks and status history. It prints the logins:

| Role | Email | Password |
|---|---|---|
| Admin | value of `ADMIN_EMAIL` (default `admin@transitcare.local`) | value of `ADMIN_PASSWORD` (default `Admin@12345`) |
| Passenger | `aarav.sharma@example.com` (any seeded passenger) | `Passenger@123` |

### Create an initial admin without seeding (development only)

```bash
npm run create-admin
# or with custom values
npm run create-admin -- --email you@example.com --password "Str0ng!Pass" --name "Your Name"
```

Creates the account, or promotes/resets an existing one. It refuses to run when `NODE_ENV=production`. Public registration can only ever create passengers, and there is no HTTP endpoint that creates the first admin.

### Run the API

```bash
npm run dev      # auto-restarts on change (Node 18.11+)
# or
npm start
```

Check it: `curl http://localhost:5000/api/health`

## 3. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env        # optional: leave VITE_API_URL empty in development
npm run dev
```

Open **http://localhost:5173**. In development Vite proxies `/api` to `http://localhost:5000`, so no CORS setup is needed. For production builds set `VITE_API_URL` to your API URL (for example `https://api.example.com/api`) and run `npm run build`.

## 5-minute demo script

1. **Home** - live statistics and the community map come from MongoDB. Click *Report a complaint*.
2. Log in as the demo passenger, open **My complaints** (personal stats, filters, table/map toggle).
3. **New complaint** - choose route 5K, a bus from the list, category, drop a pin, submit. Copy the new `TC-XXXXXXXX` ID.
4. Open **Track by ID** (works logged out) and paste the ID: status timeline shown.
5. Log out, log in as admin. **Overview** shows stats, 14-day trend, categories, busiest routes and the full map. The numbers include the complaint you just created.
6. **Complaints** - find it, *Update status* to In Progress with remarks. Re-run the tracking page to see the change.
7. Show **Buses / Routes / Users** CRUD, then **Messages** (submit one from the Contact page first).

## API documentation

Base URL: `http://localhost:5000/api`. Protected endpoints need `Authorization: Bearer <token>`.

Success: `{ "success": true, "message": "...", "data": ... }`
Error: `{ "success": false, "message": "...", "errors": [{ "field": "...", "message": "..." }] }`
Status codes: 200/201 OK, 400 validation, 401 not logged in, 403 forbidden, 404 not found, 409 conflict, 429 rate limited.

### Auth

| Method | Path | Access | Body |
|---|---|---|---|
| POST | `/auth/register` | Public | `name, email, phone?, password` (8+ chars, letter + number). Always creates a passenger |
| POST | `/auth/login` | Public | `email, password` -> `{ token, user }` |
| GET | `/auth/me` | Auth | - |
| PUT | `/auth/me` | Auth | `name?, phone?, password?` |

### Complaints

| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/complaints` | Auth | Create. `route` (id), `busNumber`, `category`, `description` (10-2000), `location {address, lat?, lng?}`, `imageUrl?`, `priority?` |
| GET | `/complaints` | Auth | Passengers: own only. Admins: all. Query: `q, status, category, priority, route, from, to, page, limit` |
| GET | `/complaints/:id` | Owner/Admin | Mongo `_id` or complaint ID |
| PUT | `/complaints/:id` | Owner (Pending only) / Admin | Edit fields; admins may also set `status, priority, adminRemarks` |
| PATCH | `/complaints/:id/status` | Admin | `status, adminRemarks?, priority?` - appends to status history |
| DELETE | `/complaints/:id` | Owner (Pending only) / Admin | |
| GET | `/complaints/track/:complaintId` | Public | Safe subset, no personal data |
| GET | `/complaints/public/map` | Public | Latest 300 anonymised map points |

Categories: Bus delay, Overcrowding, Driver behaviour, Conductor behaviour, Vehicle cleanliness, Damaged bus, Missed stop, Route issue, Other.
Statuses: Pending, In Progress, Resolved, Rejected. Priorities: Low, Medium, High, Critical.

### Buses and routes

| Method | Path | Access |
|---|---|---|
| GET | `/buses`, `/buses/:id` | Public (`?q=&route=&type=&status=`) |
| POST / PUT / DELETE | `/buses`, `/buses/:id` | Admin |
| GET | `/routes`, `/routes/:id` | Public (`?q=&active=`) |
| POST / PUT / DELETE | `/routes`, `/routes/:id` | Admin (delete blocked while buses or complaints use the route) |

### Users, stats, messages

| Method | Path | Access |
|---|---|---|
| GET / POST | `/users` | Admin |
| PUT / DELETE | `/users/:id` | Admin (cannot demote/deactivate/delete yourself; deleting a user also deletes their complaints) |
| GET | `/stats` | Public: total, pending, inProgress, resolved, rejected, resolutionRate, buses, routes |
| GET | `/stats/me` | Auth: same summary for your complaints |
| GET | `/stats/admin` | Admin: summary + users, byCategory, byPriority, 14-day trend, topRoutes |
| POST | `/messages` | Public (Contact form) |
| GET / PATCH / DELETE | `/messages`, `/messages/:id` | Admin |

`resolutionRate = resolved / total * 100`, computed by MongoDB aggregation.

### Example requests

```bash
# Register
curl -X POST http://localhost:5000/api/auth/register -H "Content-Type: application/json" \
  -d '{"name":"Test Rider","email":"rider@example.com","password":"Rider1234"}'

# Login and keep the token
TOKEN=$(curl -s -X POST http://localhost:5000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"aarav.sharma@example.com","password":"Passenger@123"}' | node -pe "JSON.parse(require('fs').readFileSync(0)).data.token")

# List routes (copy an _id)
curl http://localhost:5000/api/routes

# Create a complaint
curl -X POST http://localhost:5000/api/complaints -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"route":"<ROUTE_ID>","busNumber":"TSB-1001","category":"Bus delay","priority":"High",
       "description":"Bus was 30 minutes late at Ameerpet during peak hour.",
       "location":{"address":"Ameerpet bus stop","lat":17.4375,"lng":78.4483}}'

# My complaints, filtered
curl "http://localhost:5000/api/complaints?status=Pending&q=ameerpet" -H "Authorization: Bearer $TOKEN"

# Track publicly
curl http://localhost:5000/api/complaints/track/TC-XXXXXXXX

# Admin: update status
curl -X PATCH http://localhost:5000/api/complaints/<ID>/status -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" -d '{"status":"In Progress","adminRemarks":"Forwarded to depot manager."}'
```

## Security notes

- Passwords are hashed with the bcrypt algorithm (cost 12) via `bcryptjs` (pure JavaScript, no native build step). They are never returned by the API.
- `JWT_SECRET` and `MONGO_URI` live only in `backend/.env` (git-ignored). The frontend contains no secrets; `VITE_*` variables are public by design.
- Authorization is enforced on the server for every route (role checks plus ownership checks). Hiding buttons in the UI is only a convenience.
- Inputs are validated with express-validator; regex search input is escaped; request size is capped; auth, tracking and contact endpoints are rate limited.
- Seed and admin scripts refuse to run with `NODE_ENV=production`.

## Troubleshooting

| Problem | Fix |
|---|---|
| `FATAL: JWT_SECRET is missing...` | Set a long random `JWT_SECRET` in `backend/.env` |
| `Failed to start server ... Is MongoDB running?` | Start MongoDB (step 1) and check `MONGO_URI` |
| Frontend shows "Cannot reach the server" | Backend not running on port 5000, or change the proxy in `frontend/vite.config.js` |
| CORS error with a custom frontend URL | Add that origin to `CLIENT_URL` |
| Map tiles blank | The browser needs internet access to `tile.openstreetmap.org` |
| Address not auto-filled after dropping a pin | It uses OpenStreetMap Nominatim; type the address manually if it is unreachable |

## Verification status

The source was syntax-checked (all backend files with `node --check`, all frontend files parsed with esbuild) and every relative import/export was cross-checked. It was written in a sandbox with no network access, so `npm install`, a live MongoDB run and a browser test were **not** executed there. Run the steps above on your machine; if anything misbehaves, the error messages and troubleshooting table should point to the cause.
