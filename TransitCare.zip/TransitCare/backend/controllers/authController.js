const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const { signToken } = require('../utils/token');

const send = (res, status, user, message) =>
  res.status(status).json({ success: true, message, data: { token: signToken(user), user } });

// Public registration ALWAYS creates a passenger. Admins are created via script or by another admin.
exports.register = asyncHandler(async (req, res) => {
  const { name, email, phone, password } = req.body;
  if (await User.exists({ email })) throw new ApiError(409, 'An account with this email already exists.');
  const user = await User.create({ name, email, phone, password, role: 'passenger' });
  send(res, 201, user, 'Registration successful');
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.matchPassword(password))) throw new ApiError(401, 'Invalid email or password.');
  if (!user.active) throw new ApiError(403, 'This account has been deactivated. Contact support.');
  send(res, 200, user, 'Login successful');
});

exports.me = asyncHandler(async (req, res) => {
  res.json({ success: true, data: req.user });
});

exports.updateMe = asyncHandler(async (req, res) => {
  const { name, phone, password } = req.body;
  const user = await User.findById(req.user._id).select('+password');
  if (name) user.name = name;
  if (phone !== undefined) user.phone = phone;
  if (password) user.password = password;
  await user.save();
  res.json({ success: true, message: 'Profile updated', data: user });
});
