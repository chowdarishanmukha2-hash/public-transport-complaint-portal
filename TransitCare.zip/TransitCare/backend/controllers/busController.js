const Bus = require('../models/Bus');
const Route = require('../models/Route');
const factory = require('./crudFactory');
const ApiError = require('../utils/ApiError');

const extra = async (req, _res, next) => {
  try {
    if (req.body.route && !(await Route.exists({ _id: req.body.route }))) {
      throw new ApiError(400, 'Selected route does not exist.');
    }
    next();
  } catch (e) { next(e); }
};

module.exports = {
  ...factory(Bus, {
    label: 'Bus',
    searchFields: ['busNumber', 'driverName'],
    populate: { path: 'route', select: 'routeNumber name origin destination' },
    filters: ['route', 'status', 'type'],
  }),
  checkRouteExists: extra,
};
