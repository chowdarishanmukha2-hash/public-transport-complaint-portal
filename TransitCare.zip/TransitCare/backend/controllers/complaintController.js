const mongoose = require('mongoose');
const Complaint = require('../models/Complaint');
const Route = require('../models/Route');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const isAdmin = (u) => u.role === 'admin';
const POPULATE = [
  { path: 'route', select: 'routeNumber name origin destination' },
  { path: 'passenger', select: 'name email phone' },
];
const PASSENGER_EDITABLE = ['busNumber', 'route', 'category', 'description', 'location', 'imageUrl'];

async function findAccessible(req) {
  const { id } = req.params;
  const q = mongoose.isValidObjectId(id) ? { $or: [{ _id: id }, { complaintId: id.toUpperCase() }] } : { complaintId: id.toUpperCase() };
  const doc = await Complaint.findOne(q).populate(POPULATE);
  if (!doc) throw new ApiError(404, 'Complaint not found');
  const ownerId = doc.passenger?._id || doc.passenger;
  if (!isAdmin(req.user) && String(ownerId) !== String(req.user._id)) {
    throw new ApiError(403, 'You can only access your own complaints.');
  }
  return doc;
}

exports.create = asyncHandler(async (req, res) => {
  const b = req.body;
  if (!(await Route.exists({ _id: b.route }))) throw new ApiError(400, 'Selected route does not exist.');
  const complaint = await Complaint.create({
    passenger: req.user._id,
    busNumber: b.busNumber,
    route: b.route,
    category: b.category,
    description: b.description,
    location: b.location,
    imageUrl: b.imageUrl || '',
    priority: b.priority || 'Medium',
    status: 'Pending',
    statusHistory: [{ status: 'Pending', note: 'Complaint submitted' }],
  });
  await complaint.populate(POPULATE);
  res.status(201).json({ success: true, message: `Complaint submitted. Your ID is ${complaint.complaintId}`, data: complaint });
});

// Passengers: own complaints. Admins: all complaints. Supports filters + pagination.
exports.list = asyncHandler(async (req, res) => {
  const { q, status, category, priority, route, from, to } = req.query;
  const filter = {};
  if (!isAdmin(req.user)) filter.passenger = req.user._id;
  if (typeof status === 'string' && Complaint.STATUSES.includes(status)) filter.status = status;
  if (typeof category === 'string' && Complaint.CATEGORIES.includes(category)) filter.category = category;
  if (typeof priority === 'string' && Complaint.PRIORITIES.includes(priority)) filter.priority = priority;
  if (typeof route === 'string' && mongoose.isValidObjectId(route)) filter.route = route;
  if (typeof q === 'string' && q.trim()) {
    const rx = new RegExp(escapeRegex(q.trim()), 'i');
    filter.$or = [{ complaintId: rx }, { busNumber: rx }, { description: rx }, { 'location.address': rx }];
  }
  const range = {};
  if (typeof from === 'string' && !isNaN(Date.parse(from))) range.$gte = new Date(from);
  if (typeof to === 'string' && !isNaN(Date.parse(to))) range.$lte = new Date(new Date(to).setHours(23, 59, 59, 999));
  if (Object.keys(range).length) filter.createdAt = range;

  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 200);
  const [data, total] = await Promise.all([
    Complaint.find(filter).populate(POPULATE).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    Complaint.countDocuments(filter),
  ]);
  res.json({ success: true, data, pagination: { page, limit, total, pages: Math.ceil(total / limit) || 1 } });
});

exports.getOne = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await findAccessible(req) });
});

// Edit: passengers can edit their own complaint only while Pending. Admins can edit everything.
exports.update = asyncHandler(async (req, res) => {
  const doc = await findAccessible(req);
  const admin = isAdmin(req.user);
  if (!admin && doc.status !== 'Pending') {
    throw new ApiError(409, 'This complaint is already being handled and can no longer be edited.');
  }
  if (req.body.route && !(await Route.exists({ _id: req.body.route }))) throw new ApiError(400, 'Selected route does not exist.');

  const fields = admin ? [...PASSENGER_EDITABLE, 'priority', 'adminRemarks'] : PASSENGER_EDITABLE;
  for (const f of fields) if (req.body[f] !== undefined) doc.set(f, req.body[f]);
  if (admin && req.body.status && req.body.status !== doc.status) {
    doc.status = req.body.status;
    doc.statusHistory.push({ status: req.body.status, note: req.body.adminRemarks || '' });
  }
  await doc.save();
  await doc.populate(POPULATE);
  res.json({ success: true, message: 'Complaint updated', data: doc });
});

// Admin only: change status (+ optional remarks / priority)
exports.updateStatus = asyncHandler(async (req, res) => {
  const doc = await findAccessible(req);
  const { status, adminRemarks, priority } = req.body;
  if (adminRemarks !== undefined) doc.adminRemarks = adminRemarks;
  if (priority) doc.priority = priority;
  if (status !== doc.status || adminRemarks) {
    doc.statusHistory.push({ status, note: adminRemarks || '' });
  }
  doc.status = status;
  doc.markModified('statusHistory');
  doc.updatedAt = new Date();
  await doc.save();
  res.json({ success: true, message: `Status updated to ${status}`, data: doc });
});

// Owner (while Pending) or admin
exports.remove = asyncHandler(async (req, res) => {
  const doc = await findAccessible(req);
  if (!isAdmin(req.user) && doc.status !== 'Pending') {
    throw new ApiError(409, 'Only pending complaints can be withdrawn.');
  }
  await doc.deleteOne();
  res.json({ success: true, message: 'Complaint deleted' });
});

// Public: track by complaint ID (no personal data exposed)
exports.track = asyncHandler(async (req, res) => {
  const doc = await Complaint.findOne({ complaintId: String(req.params.complaintId).trim().toUpperCase() })
    .populate('route', 'routeNumber name origin destination');
  if (!doc) throw new ApiError(404, 'No complaint found with that ID. Check the ID and try again.');
  res.json({
    success: true,
    data: {
      complaintId: doc.complaintId, busNumber: doc.busNumber, route: doc.route, category: doc.category,
      status: doc.status, priority: doc.priority, location: doc.location, adminRemarks: doc.adminRemarks,
      statusHistory: doc.statusHistory, createdAt: doc.createdAt, updatedAt: doc.updatedAt,
    },
  });
});

// Public, anonymised markers for the community map
exports.publicMap = asyncHandler(async (_req, res) => {
  const docs = await Complaint.find({ 'location.lat': { $ne: null }, 'location.lng': { $ne: null } })
    .sort({ createdAt: -1 }).limit(300)
    .select('complaintId category status priority busNumber location.lat location.lng location.address createdAt');
  res.json({ success: true, count: docs.length, data: docs });
});
