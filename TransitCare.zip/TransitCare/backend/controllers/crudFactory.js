const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Generic CRUD handlers used for Buses and Routes.
 * opts: { label, searchFields, populate, filters: [queryParamNames], beforeDelete(doc) }
 */
module.exports = (Model, opts) => {
  const { label, searchFields = [], populate = '', filters = [], beforeDelete } = opts;

  const withPop = (q) => (populate ? q.populate(populate) : q);
  const popDoc = async (d) => (populate ? d.populate(populate) : d);

  const list = asyncHandler(async (req, res) => {
    const query = {};
    for (const f of filters) if (typeof req.query[f] === 'string' && req.query[f]) query[f] = req.query[f];
    if (typeof req.query.q === 'string' && req.query.q.trim()) {
      const rx = new RegExp(escapeRegex(req.query.q.trim()), 'i');
      query.$or = searchFields.map((f) => ({ [f]: rx }));
    }
    const docs = await withPop(Model.find(query)).sort({ createdAt: -1 }).limit(500);
    res.json({ success: true, count: docs.length, data: docs });
  });

  const get = asyncHandler(async (req, res) => {
    const doc = await withPop(Model.findById(req.params.id));
    if (!doc) throw new ApiError(404, `${label} not found`);
    res.json({ success: true, data: doc });
  });

  const create = asyncHandler(async (req, res) => {
    const doc = await Model.create(req.body);
    res.status(201).json({ success: true, message: `${label} created`, data: await popDoc(doc) });
  });

  const update = asyncHandler(async (req, res) => {
    const doc = await Model.findById(req.params.id);
    if (!doc) throw new ApiError(404, `${label} not found`);
    doc.set(req.body);
    await doc.save();
    res.json({ success: true, message: `${label} updated`, data: await popDoc(doc) });
  });

  const remove = asyncHandler(async (req, res) => {
    const doc = await Model.findById(req.params.id);
    if (!doc) throw new ApiError(404, `${label} not found`);
    if (beforeDelete) await beforeDelete(doc);
    await doc.deleteOne();
    res.json({ success: true, message: `${label} deleted` });
  });

  return { list, get, create, update, remove };
};
