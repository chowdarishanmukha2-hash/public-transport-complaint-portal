const Message = require('../models/Message');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

exports.create = asyncHandler(async (req, res) => {
  const { name, email, subject, message } = req.body;
  await Message.create({ name, email, subject, message });
  res.status(201).json({ success: true, message: 'Thanks! Your message has been sent to the TransitCare team.' });
});

exports.list = asyncHandler(async (_req, res) => {
  const data = await Message.find().sort({ createdAt: -1 }).limit(200);
  res.json({ success: true, count: data.length, data });
});

exports.markRead = asyncHandler(async (req, res) => {
  const doc = await Message.findByIdAndUpdate(req.params.id, { read: req.body.read !== false }, { new: true });
  if (!doc) throw new ApiError(404, 'Message not found');
  res.json({ success: true, data: doc });
});

exports.remove = asyncHandler(async (req, res) => {
  const doc = await Message.findByIdAndDelete(req.params.id);
  if (!doc) throw new ApiError(404, 'Message not found');
  res.json({ success: true, message: 'Message deleted' });
});
