const Route = require('../models/Route');
const Bus = require('../models/Bus');
const Complaint = require('../models/Complaint');
const factory = require('./crudFactory');
const ApiError = require('../utils/ApiError');

module.exports = factory(Route, {
  label: 'Route',
  searchFields: ['routeNumber', 'name', 'origin', 'destination', 'stops.name'],
  filters: ['active'],
  beforeDelete: async (route) => {
    const [buses, complaints] = await Promise.all([
      Bus.countDocuments({ route: route._id }),
      Complaint.countDocuments({ route: route._id }),
    ]);
    if (buses || complaints) {
      throw new ApiError(409, `Cannot delete: route has ${buses} bus(es) and ${complaints} complaint(s). Mark it inactive instead.`);
    }
  },
});
