const Complaint = require('../models/Complaint');
const Bus = require('../models/Bus');
const Route = require('../models/Route');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');

async function summary(match = {}) {
  const rows = await Complaint.aggregate([{ $match: match }, { $group: { _id: '$status', n: { $sum: 1 } } }]);
  const c = Object.fromEntries(rows.map((r) => [r._id, r.n]));
  const total = rows.reduce((a, r) => a + r.n, 0);
  const resolved = c.Resolved || 0;
  return {
    total,
    pending: c.Pending || 0,
    inProgress: c['In Progress'] || 0,
    resolved,
    rejected: c.Rejected || 0,
    resolutionRate: total ? Math.round((resolved / total) * 1000) / 10 : 0,
  };
}

// Public (home page)
exports.publicStats = asyncHandler(async (_req, res) => {
  const [s, buses, routes] = await Promise.all([summary(), Bus.countDocuments(), Route.countDocuments()]);
  res.json({ success: true, data: { ...s, buses, routes } });
});

exports.myStats = asyncHandler(async (req, res) => {
  res.json({ success: true, data: await summary({ passenger: req.user._id }) });
});

exports.adminStats = asyncHandler(async (_req, res) => {
  const since = new Date(Date.now() - 13 * 24 * 3600 * 1000);
  since.setHours(0, 0, 0, 0);
  const [s, byCategory, byPriority, trendRaw, topRoutes, users, buses, routes] = await Promise.all([
    summary(),
    Complaint.aggregate([{ $group: { _id: '$category', count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
    Complaint.aggregate([{ $group: { _id: '$priority', count: { $sum: 1 } } }]),
    Complaint.aggregate([
      { $match: { createdAt: { $gte: since } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, count: { $sum: 1 } } },
    ]),
    Complaint.aggregate([
      { $group: { _id: '$route', count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 5 },
      { $lookup: { from: 'routes', localField: '_id', foreignField: '_id', as: 'route' } },
      { $unwind: '$route' },
      { $project: { _id: 0, routeNumber: '$route.routeNumber', name: '$route.name', count: 1 } },
    ]),
    User.countDocuments(), Bus.countDocuments(), Route.countDocuments(),
  ]);
  const map = Object.fromEntries(trendRaw.map((r) => [r._id, r.count]));
  const trend = [];
  for (let i = 0; i < 14; i++) {
    const d = new Date(since.getTime() + i * 24 * 3600 * 1000);
    const key = d.toISOString().slice(0, 10);
    trend.push({ date: key, count: map[key] || 0 });
  }
  res.json({
    success: true,
    data: {
      ...s, users, buses, routes, topRoutes, trend,
      byCategory: byCategory.map((r) => ({ category: r._id, count: r.count })),
      byPriority: byPriority.map((r) => ({ priority: r._id, count: r.count })),
    },
  });
});
