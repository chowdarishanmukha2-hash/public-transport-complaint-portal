const User = require('../models/User');
const Complaint = require('../models/Complaint');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (['passenger', 'admin'].includes(req.query.role)) filter.role = req.query.role;
  if (typeof req.query.q === 'string' && req.query.q.trim()) {
    const rx = new RegExp(escapeRegex(req.query.q.trim()), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }
  const users = await User.find(filter).sort({ createdAt: -1 }).limit(500);
  const counts = await Complaint.aggregate([{ $group: { _id: '$passenger', n: { $sum: 1 } } }]);
  const map = Object.fromEntries(counts.map((c) => [String(c._id), c.n]));
  const data = users.map((u) => ({ ...u.toJSON(), complaintCount: map[String(u._id)] || 0 }));
  res.json({ success: true, count: data.length, data });
});

exports.create = asyncHandler(async (req, res) => {
  const user = await User.create(req.body);
  res.status(201).json({ success: true, message: 'User created', data: user });
});

exports.update = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).select('+password');
  if (!user) throw new ApiError(404, 'User not found');
  const isSelf = String(user._id) === String(req.user._id);
  if (isSelf && (req.body.role === 'passenger' || req.body.active === false)) {
    throw new ApiError(400, 'You cannot demote or deactivate your own account.');
  }
  for (const f of ['name', 'phone', 'role', 'active', 'password']) if (req.body[f] !== undefined && req.body[f] !== '') user.set(f, req.body[f]);
  await user.save();
  res.json({ success: true, message: 'User updated', data: user });
});

// Deletes the user and all complaints they filed
exports.remove = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new ApiError(404, 'User not found');
  if (String(user._id) === String(req.user._id)) throw new ApiError(400, 'You cannot delete your own account.');
  const { deletedCount } = await Complaint.deleteMany({ passenger: user._id });
  await user.deleteOne();
  res.json({ success: true, message: `User deleted (${deletedCount} complaint(s) removed)` });
});
