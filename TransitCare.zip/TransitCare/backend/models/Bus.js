const mongoose = require('mongoose');

const busSchema = new mongoose.Schema(
  {
    busNumber: { type: String, required: true, unique: true, uppercase: true, trim: true },
    route: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', required: true },
    type: { type: String, enum: ['Ordinary', 'Express', 'AC', 'Electric'], default: 'Ordinary' },
    capacity: { type: Number, min: 1, default: 50 },
    driverName: { type: String, trim: true, default: '' },
    status: { type: String, enum: ['Active', 'Maintenance', 'Inactive'], default: 'Active' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Bus', busSchema);
