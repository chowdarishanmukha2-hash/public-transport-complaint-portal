const mongoose = require('mongoose');
const crypto = require('crypto');

const CATEGORIES = [
  'Bus delay', 'Overcrowding', 'Driver behaviour', 'Conductor behaviour', 'Vehicle cleanliness',
  'Damaged bus', 'Missed stop', 'Route issue', 'Other',
];
const STATUSES = ['Pending', 'In Progress', 'Resolved', 'Rejected'];
const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];

const historySchema = new mongoose.Schema(
  {
    status: { type: String, enum: STATUSES },
    note: { type: String, default: '' },
    at: { type: Date, default: Date.now },
  },
  { _id: false }
);

const complaintSchema = new mongoose.Schema(
  {
    complaintId: { type: String, unique: true, index: true },
    passenger: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    busNumber: { type: String, required: true, uppercase: true, trim: true },
    route: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', required: true },
    category: { type: String, enum: CATEGORIES, required: true },
    description: { type: String, required: true, trim: true, minlength: 10, maxlength: 2000 },
    location: {
      address: { type: String, required: true, trim: true, maxlength: 300 },
      lat: { type: Number, min: -90, max: 90 },
      lng: { type: Number, min: -180, max: 180 },
    },
    imageUrl: { type: String, trim: true, default: '' },
    priority: { type: String, enum: PRIORITIES, default: 'Medium' },
    status: { type: String, enum: STATUSES, default: 'Pending', index: true },
    adminRemarks: { type: String, default: '', maxlength: 1000 },
    statusHistory: { type: [historySchema], default: [] },
  },
  { timestamps: true } // createdAt = creation date, updatedAt = last updated date
);

// Human-friendly unique ID, e.g. TC-7F3K9Q2A
complaintSchema.pre('validate', async function () {
  if (this.complaintId) return;
  for (let i = 0; i < 5; i++) {
    const id = 'TC-' + crypto.randomBytes(5).toString('hex').toUpperCase().slice(0, 8);
    if (!(await this.constructor.exists({ complaintId: id }))) {
      this.complaintId = id;
      return;
    }
  }
  throw new Error('Could not generate a unique complaint ID');
});

complaintSchema.statics.CATEGORIES = CATEGORIES;
complaintSchema.statics.STATUSES = STATUSES;
complaintSchema.statics.PRIORITIES = PRIORITIES;

module.exports = mongoose.model('Complaint', complaintSchema);
