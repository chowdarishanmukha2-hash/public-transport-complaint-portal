const mongoose = require('mongoose');

const stopSchema = new mongoose.Schema(
  { name: { type: String, required: true, trim: true }, lat: Number, lng: Number },
  { _id: false }
);

const routeSchema = new mongoose.Schema(
  {
    routeNumber: { type: String, required: true, unique: true, uppercase: true, trim: true },
    name: { type: String, required: true, trim: true },
    origin: { type: String, required: true, trim: true },
    destination: { type: String, required: true, trim: true },
    stops: { type: [stopSchema], default: [] },
    distanceKm: { type: Number, min: 0, default: 0 },
    frequencyMins: { type: Number, min: 1, default: 15 },
    firstBus: { type: String, default: '05:30' },
    lastBus: { type: String, default: '23:00' },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Route', routeSchema);
