const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect } = require('../middleware/auth');
const c = require('../controllers/authController');

const password = body('password').isString().isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters')
  .matches(/[A-Za-z]/).withMessage('Password must contain a letter').matches(/\d/).withMessage('Password must contain a number');

router.post('/register', [
  body('name').isString().trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  body('email').isString().isEmail().withMessage('Enter a valid email').normalizeEmail(),
  body('phone').optional({ values: 'falsy' }).isString().trim().matches(/^[0-9+\-\s()]{7,15}$/).withMessage('Enter a valid phone number'),
  password, validate,
], c.register);

router.post('/login', [
  body('email').isString().isEmail().withMessage('Enter a valid email').normalizeEmail(),
  body('password').isString().notEmpty().withMessage('Password is required'),
  validate,
], c.login);

router.get('/me', protect, c.me);
router.put('/me', protect, [
  body('name').optional().isString().trim().isLength({ min: 2, max: 80 }),
  body('phone').optional({ values: 'falsy' }).isString().trim().matches(/^[0-9+\-\s()]{7,15}$/).withMessage('Enter a valid phone number'),
  body('password').optional({ values: 'falsy' }).isString().isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters'),
  validate,
], c.updateMe);

module.exports = router;
