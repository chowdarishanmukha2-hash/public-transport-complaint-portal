const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/busController');

const rules = (req) => [
  (req ? body('busNumber').exists() : body('busNumber').optional()).isString().trim().isLength({ min: 2, max: 30 }).withMessage('Bus number is required'),
  (req ? body('route').exists() : body('route').optional()).isMongoId().withMessage('Select a valid route'),
  body('type').optional().isIn(['Ordinary', 'Express', 'AC', 'Electric']),
  body('capacity').optional().isInt({ min: 1, max: 200 }).withMessage('Capacity must be 1-200'),
  body('status').optional().isIn(['Active', 'Maintenance', 'Inactive']),
  body('driverName').optional({ values: 'falsy' }).isString().trim().isLength({ max: 80 }),
  validate, c.checkRouteExists,
];

router.get('/', c.list);
router.get('/:id', c.get);
router.post('/', protect, authorize('admin'), rules(true), c.create);
router.put('/:id', protect, authorize('admin'), rules(false), c.update);
router.delete('/:id', protect, authorize('admin'), c.remove);

module.exports = router;
