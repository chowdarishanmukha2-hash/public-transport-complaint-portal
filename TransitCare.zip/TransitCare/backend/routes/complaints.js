const router = require('express').Router();
const { body, param } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const Complaint = require('../models/Complaint');
const c = require('../controllers/complaintController');

const fields = (required) => {
  const opt = (chain) => (required ? chain : chain.optional());
  return [
    opt(body('busNumber').isString().trim().isLength({ min: 2, max: 30 })).withMessage('Bus number is required'),
    opt(body('route').isMongoId()).withMessage('Select a valid route'),
    opt(body('category').isIn(Complaint.CATEGORIES)).withMessage('Select a valid category'),
    opt(body('description').isString().trim().isLength({ min: 10, max: 2000 })).withMessage('Description must be 10-2000 characters'),
    opt(body('location.address').isString().trim().isLength({ min: 3, max: 300 })).withMessage('Location is required'),
    body('location.lat').optional({ nullable: true }).isFloat({ min: -90, max: 90 }).withMessage('Invalid latitude').toFloat(),
    body('location.lng').optional({ nullable: true }).isFloat({ min: -180, max: 180 }).withMessage('Invalid longitude').toFloat(),
    body('imageUrl').optional({ values: 'falsy' }).isURL({ protocols: ['http', 'https'], require_protocol: true }).withMessage('Image must be a valid http(s) URL'),
    body('priority').optional().isIn(Complaint.PRIORITIES).withMessage('Invalid priority'),
  ];
};

// Public
router.get('/track/:complaintId', [param('complaintId').isString().trim().isLength({ min: 4, max: 30 }), validate], c.track);
router.get('/public/map', c.publicMap);

// Authenticated
router.use(protect);
router.route('/').get(c.list).post([...fields(true), validate], c.create);
router.route('/:id')
  .get(c.getOne)
  .put([...fields(false),
    body('status').optional().isIn(Complaint.STATUSES), body('adminRemarks').optional().isString().isLength({ max: 1000 }), validate], c.update)
  .delete(c.remove);
router.patch('/:id/status', authorize('admin'), [
  body('status').isIn(Complaint.STATUSES).withMessage('Status must be Pending, In Progress, Resolved or Rejected'),
  body('adminRemarks').optional().isString().isLength({ max: 1000 }),
  body('priority').optional().isIn(Complaint.PRIORITIES),
  validate,
], c.updateStatus);

module.exports = router;
