const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/messageController');

router.post('/', [
  body('name').isString().trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  body('email').isString().isEmail().withMessage('Enter a valid email').normalizeEmail(),
  body('subject').isString().trim().isLength({ min: 3, max: 120 }).withMessage('Subject must be 3-120 characters'),
  body('message').isString().trim().isLength({ min: 10, max: 2000 }).withMessage('Message must be 10-2000 characters'),
  validate,
], c.create);

router.get('/', protect, authorize('admin'), c.list);
router.patch('/:id', protect, authorize('admin'), c.markRead);
router.delete('/:id', protect, authorize('admin'), c.remove);

module.exports = router;
