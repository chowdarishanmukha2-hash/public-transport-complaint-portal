const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/routeController');

const rules = (req) => [
  (req ? body('routeNumber').exists() : body('routeNumber').optional()).isString().trim().isLength({ min: 1, max: 20 }).withMessage('Route number is required'),
  (req ? body('name').exists() : body('name').optional()).isString().trim().isLength({ min: 2, max: 120 }).withMessage('Route name is required'),
  (req ? body('origin').exists() : body('origin').optional()).isString().trim().notEmpty().withMessage('Origin is required'),
  (req ? body('destination').exists() : body('destination').optional()).isString().trim().notEmpty().withMessage('Destination is required'),
  body('stops').optional().isArray({ max: 60 }).withMessage('Stops must be a list'),
  body('stops.*.name').isString().trim().notEmpty().withMessage('Each stop needs a name'),
  body('stops.*.lat').optional({ nullable: true }).isFloat({ min: -90, max: 90 }),
  body('stops.*.lng').optional({ nullable: true }).isFloat({ min: -180, max: 180 }),
  body('distanceKm').optional().isFloat({ min: 0 }),
  body('frequencyMins').optional().isInt({ min: 1, max: 240 }),
  body('firstBus').optional().matches(/^\d{2}:\d{2}$/).withMessage('Use HH:MM'),
  body('lastBus').optional().matches(/^\d{2}:\d{2}$/).withMessage('Use HH:MM'),
  body('active').optional().isBoolean(),
  validate,
];

router.get('/', c.list);
router.get('/:id', c.get);
router.post('/', protect, authorize('admin'), rules(true), c.create);
router.put('/:id', protect, authorize('admin'), rules(false), c.update);
router.delete('/:id', protect, authorize('admin'), c.remove);

module.exports = router;
