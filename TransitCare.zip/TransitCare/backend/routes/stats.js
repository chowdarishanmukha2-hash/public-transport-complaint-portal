const router = require('express').Router();
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/statsController');

router.get('/', c.publicStats);
router.get('/me', protect, c.myStats);
router.get('/admin', protect, authorize('admin'), c.adminStats);

module.exports = router;
