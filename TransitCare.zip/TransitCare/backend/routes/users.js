const router = require('express').Router();
const { body } = require('express-validator');
const validate = require('../middleware/validate');
const { protect, authorize } = require('../middleware/auth');
const c = require('../controllers/userController');

router.use(protect, authorize('admin'));
router.get('/', c.list);
router.post('/', [
  body('name').isString().trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  body('email').isString().isEmail().withMessage('Enter a valid email').normalizeEmail(),
  body('password').isString().isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters'),
  body('role').optional().isIn(['passenger', 'admin']),
  validate,
], c.create);
router.put('/:id', [
  body('name').optional().isString().trim().isLength({ min: 2, max: 80 }),
  body('role').optional().isIn(['passenger', 'admin']),
  body('active').optional().isBoolean().toBoolean(),
  body('password').optional({ values: 'falsy' }).isString().isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters'),
  validate,
], c.update);
router.delete('/:id', c.remove);

module.exports = router;
