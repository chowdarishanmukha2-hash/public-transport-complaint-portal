/**
 * DEVELOPMENT-ONLY helper to create (or promote) an admin account.
 *
 *   npm run create-admin
 *   npm run create-admin -- --email you@example.com --password "Str0ngPass!" --name "Your Name"
 *
 * Reads ADMIN_NAME / ADMIN_EMAIL / ADMIN_PASSWORD from backend/.env unless flags are given.
 * Refuses to run when NODE_ENV=production. There is NO public endpoint that creates admins.
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');

const arg = (name) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : undefined;
};

(async () => {
  if (process.env.NODE_ENV === 'production') {
    console.error('Refusing to run: create-admin is a development-only script (NODE_ENV=production).');
    process.exit(1);
  }
  const name = arg('name') || process.env.ADMIN_NAME || 'TransitCare Admin';
  const email = (arg('email') || process.env.ADMIN_EMAIL || '').toLowerCase();
  const password = arg('password') || process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 8) {
    console.error('Provide an email and a password of 8+ characters (via .env or --email / --password).');
    process.exit(1);
  }
  await mongoose.connect(process.env.MONGO_URI);
  let user = await User.findOne({ email });
  if (user) {
    user.role = 'admin'; user.active = true; user.password = password; user.name = name;
    await user.save();
    console.log(`Existing user promoted to admin and password reset: ${email}`);
  } else {
    user = await User.create({ name, email, password, role: 'admin' });
    console.log(`Admin created: ${email}`);
  }
  await mongoose.disconnect();
})().catch((e) => { console.error(e.message); process.exit(1); });
