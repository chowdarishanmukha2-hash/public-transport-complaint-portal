/**
 * DEVELOPMENT-ONLY demo data seeder. WIPES users, buses, routes, complaints and messages.
 *   npm run seed
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Route = require('../models/Route');
const Bus = require('../models/Bus');
const Complaint = require('../models/Complaint');
const Message = require('../models/Message');

const PASSENGER_PASSWORD = 'Passenger@123';

// Stop coordinates (Hyderabad). Route numbers are fictional demo values.
const S = {
  Secunderabad: [17.4337, 78.5014], Paradise: [17.4416, 78.4863], Begumpet: [17.444, 78.462],
  Ameerpet: [17.4375, 78.4483], Panjagutta: [17.426, 78.4505], 'Banjara Hills': [17.4106, 78.438],
  Mehdipatnam: [17.396, 78.44], 'Jubilee Hills': [17.4326, 78.4071], Madhapur: [17.4486, 78.3908],
  'HITEC City': [17.4435, 78.3772], Gachibowli: [17.4401, 78.3489], Kondapur: [17.4637, 78.3641],
  Lingampally: [17.4937, 78.3175], Charminar: [17.3616, 78.4747], Afzalgunj: [17.3733, 78.477],
  Nampally: [17.3924, 78.469], Koti: [17.385, 78.4867], 'LB Nagar': [17.3457, 78.5522],
  Dilsukhnagar: [17.3688, 78.5247], Uppal: [17.4018, 78.56], Tarnaka: [17.4286, 78.5345],
  Kukatpally: [17.4948, 78.3996], Miyapur: [17.4968, 78.3563], 'Airport (Shamshabad)': [17.2403, 78.4294],
  Rajendranagar: [17.323, 78.4], Attapur: [17.3667, 78.4283],
};
const stops = (names) => names.map((n) => ({ name: n, lat: S[n][0], lng: S[n][1] }));

const ROUTES = [
  { routeNumber: '5K', name: 'Secunderabad - Gachibowli', stops: ['Secunderabad', 'Paradise', 'Begumpet', 'Ameerpet', 'Madhapur', 'HITEC City', 'Gachibowli'], distanceKm: 27, frequencyMins: 8 },
  { routeNumber: '9X', name: 'Charminar - Miyapur Express', stops: ['Charminar', 'Afzalgunj', 'Nampally', 'Panjagutta', 'Ameerpet', 'Kukatpally', 'Miyapur'], distanceKm: 31, frequencyMins: 12 },
  { routeNumber: '18', name: 'LB Nagar - Mehdipatnam', stops: ['LB Nagar', 'Dilsukhnagar', 'Koti', 'Nampally', 'Mehdipatnam'], distanceKm: 19, frequencyMins: 10 },
  { routeNumber: '27', name: 'Uppal - Lingampally', stops: ['Uppal', 'Tarnaka', 'Secunderabad', 'Begumpet', 'Ameerpet', 'Madhapur', 'Kondapur', 'Lingampally'], distanceKm: 38, frequencyMins: 15 },
  { routeNumber: '33A', name: 'Airport - Secunderabad', stops: ['Airport (Shamshabad)', 'Rajendranagar', 'Attapur', 'Mehdipatnam', 'Panjagutta', 'Begumpet', 'Secunderabad'], distanceKm: 36, frequencyMins: 20 },
  { routeNumber: '44', name: 'Kukatpally - Koti', stops: ['Kukatpally', 'Madhapur', 'Jubilee Hills', 'Banjara Hills', 'Nampally', 'Koti'], distanceKm: 24, frequencyMins: 14 },
].map((r) => ({ ...r, origin: r.stops[0], destination: r.stops[r.stops.length - 1], stops: stops(r.stops) }));

const BUS_TYPES = ['Ordinary', 'Express', 'AC', 'Electric'];
const DRIVERS = ['Ramesh Naidu', 'Suresh Babu', 'Imran Khan', 'Venkat Reddy', 'Anil Kumar', 'Mohd. Saleem', 'Prakash Rao', 'Srinivas Goud'];
const PASSENGERS = [
  ['Aarav Sharma', 'aarav.sharma@example.com', '9876500011'], ['Priya Reddy', 'priya.reddy@example.com', '9876500012'],
  ['Mohammed Faisal', 'faisal.m@example.com', '9876500013'], ['Sneha Iyer', 'sneha.iyer@example.com', '9876500014'],
  ['Karthik Varma', 'karthik.varma@example.com', '9876500015'], ['Lakshmi Devi', 'lakshmi.devi@example.com', '9876500016'],
];

const TEXT = {
  'Bus delay': ['Bus arrived 35 minutes late during morning peak and I missed an important meeting. No announcement was made at the stop.', 'The scheduled bus did not show up for over 40 minutes. Two buses arrived together afterwards.'],
  Overcrowding: ['Bus was dangerously overcrowded, people hanging at the door. Conductor kept boarding passengers beyond capacity.', 'Women\'s section was completely blocked by standing passengers; very unsafe during evening hours.'],
  'Driver behaviour': ['Driver was speeding and overtaking recklessly on the flyover. Passengers were shouting for him to slow down.', 'Driver refused to stop at the designated stop and used his phone while driving.'],
  'Conductor behaviour': ['Conductor behaved rudely and refused to return the change after issuing the ticket.', 'Conductor shouted at a senior citizen who asked for the concession fare.'],
  'Vehicle cleanliness': ['Seats were dirty and the floor had garbage. There was a strong smell inside the bus.', 'Windows were sticky and covered in dust; the bus clearly had not been cleaned in days.'],
  'Damaged bus': ['Seat frame is broken and the emergency exit latch is stuck. Rain water leaks through the roof.', 'Bus rear door would not close properly and the handrails near the entrance are loose.'],
  'Missed stop': ['The bus skipped the stop even though I rang the bell and several passengers were waiting.', 'Driver did not halt at the scheduled stop; I had to get off one kilometre later.'],
  'Route issue': ['Bus took an unannounced diversion and skipped three stops on the published route.', 'Route board shows a different destination from where the bus actually terminated.'],
  Other: ['Display board inside the bus is not working and no stop announcements were made.', 'Found the bus tracking information on the app is wrong; it showed the bus 10 minutes away for 30 minutes.'],
};
const CAT_PRIORITY = {
  'Driver behaviour': ['High', 'Critical'], 'Damaged bus': ['High', 'Medium'], Overcrowding: ['High', 'Medium'],
  'Bus delay': ['Medium', 'Low'], 'Conductor behaviour': ['Medium', 'High'], 'Vehicle cleanliness': ['Low', 'Medium'],
  'Missed stop': ['Medium', 'Low'], 'Route issue': ['Medium', 'Low'], Other: ['Low', 'Medium'],
};
const REMARKS = {
  'In Progress': ['Forwarded to depot manager for inquiry.', 'Inspection scheduled with the fleet supervisor.', 'Crew has been asked to submit a written explanation.'],
  Resolved: ['Issue verified and corrective action taken. Crew counselled.', 'Bus sent for repair and cleared by the depot engineer.', 'Frequency adjusted on this route during peak hours.'],
  Rejected: ['Unable to verify: the bus was not on duty at the reported time.', 'Duplicate of an earlier complaint that is already being handled.'],
};

// Deterministic RNG so every seed run gives the same dataset
let seed = 20240607;
const rnd = () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const pick = (a) => a[Math.floor(rnd() * a.length)];
const HOUR = 3600 * 1000;

(async () => {
  if (process.env.NODE_ENV === 'production') { console.error('Refusing to seed when NODE_ENV=production.'); process.exit(1); }
  if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) { console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD in backend/.env first.'); process.exit(1); }
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Clearing existing data...');
  await Promise.all([User.deleteMany({}), Route.deleteMany({}), Bus.deleteMany({}), Complaint.deleteMany({}), Message.deleteMany({})]);

  const admin = await User.create({ name: process.env.ADMIN_NAME || 'TransitCare Admin', email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD, role: 'admin' });
  const passengers = [];
  for (const [name, email, phone] of PASSENGERS) passengers.push(await User.create({ name, email, phone, password: PASSENGER_PASSWORD }));

  const routes = await Route.insertMany(ROUTES);
  const buses = [];
  let n = 1001;
  routes.forEach((r, ri) => {
    for (let k = 0; k < 3; k++) {
      buses.push({ busNumber: `TSB-${n++}`, route: r._id, type: BUS_TYPES[(ri + k) % 4], capacity: [52, 45, 40, 36][(ri + k) % 4], driverName: pick(DRIVERS), status: n % 9 === 0 ? 'Maintenance' : 'Active' });
    }
  });
  const busDocs = await Bus.insertMany(buses);

  // Complaints (raw insert so we can backdate createdAt / updatedAt)
  const crypto = require('crypto');
  const usedIds = new Set();
  const cats = Complaint.CATEGORIES;
  const docs = [];
  const now = Date.now();
  for (let i = 0; i < 64; i++) {
    const bus = pick(busDocs);
    const route = routes.find((r) => String(r._id) === String(bus.route));
    const stop = pick(route.stops);
    const category = i < 9 ? cats[i] : pick([cats[0], cats[0], cats[1], cats[1], cats[2], cats[3], cats[4], cats[5], cats[6], cats[7], cats[8]]);
    const roll = rnd();
    const status = roll < 0.27 ? 'Pending' : roll < 0.52 ? 'In Progress' : roll < 0.92 ? 'Resolved' : 'Rejected';
    const createdAt = new Date(now - Math.floor(rnd() * 45 * 24) * HOUR - Math.floor(rnd() * 12) * HOUR);
    const history = [{ status: 'Pending', note: 'Complaint submitted', at: createdAt }];
    let updatedAt = createdAt;
    if (status !== 'Pending') {
      updatedAt = new Date(Math.min(now, createdAt.getTime() + (2 + Math.floor(rnd() * 20)) * HOUR));
      history.push({ status: 'In Progress', note: status === 'In Progress' ? pick(REMARKS['In Progress']) : 'Complaint assigned to depot team', at: updatedAt });
    }
    let remarks = status === 'In Progress' ? history[1].note : '';
    if (status === 'Resolved' || status === 'Rejected') {
      updatedAt = new Date(Math.min(now, updatedAt.getTime() + (6 + Math.floor(rnd() * 60)) * HOUR));
      remarks = pick(REMARKS[status]);
      history.push({ status, note: remarks, at: updatedAt });
    }
    let complaintId;
    do { complaintId = 'TC-' + crypto.randomBytes(4).toString('hex').toUpperCase(); } while (usedIds.has(complaintId));
    usedIds.add(complaintId);
    docs.push({
      complaintId, passenger: pick(passengers)._id, busNumber: bus.busNumber, route: route._id, category,
      description: pick(TEXT[category]),
      location: { address: `Near ${stop.name} bus stop, Hyderabad`, lat: +(stop.lat + (rnd() - 0.5) * 0.006).toFixed(6), lng: +(stop.lng + (rnd() - 0.5) * 0.006).toFixed(6) },
      imageUrl: '', priority: pick(CAT_PRIORITY[category]), status, adminRemarks: remarks, statusHistory: history, createdAt, updatedAt, __v: 0,
    });
  }
  await Complaint.collection.insertMany(docs);

  await Message.insertMany([
    { name: 'Rohit Menon', email: 'rohit.menon@example.com', subject: 'Request for a late-night service', message: 'Could route 27 run a last bus after 11 PM? Many IT employees end shifts late and have no safe way home.' },
    { name: 'Anita Joseph', email: 'anita.j@example.com', subject: 'Great response time', message: 'My complaint about a cleanliness issue was resolved within two days. Thank you to the TransitCare team!' },
  ]);

  console.log(`\nSeeded: 1 admin, ${passengers.length} passengers, ${routes.length} routes, ${busDocs.length} buses, ${docs.length} complaints.\n`);
  console.log(`Admin login     : ${admin.email}  /  ${process.env.ADMIN_PASSWORD}`);
  console.log(`Passenger login : ${PASSENGERS[0][1]}  /  ${PASSENGER_PASSWORD}  (all demo passengers share this password)\n`);
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
