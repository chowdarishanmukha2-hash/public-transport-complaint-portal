require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');
const { notFound, errorHandler } = require('./middleware/error');

const weak = !process.env.JWT_SECRET || process.env.JWT_SECRET.startsWith('replace_me') || process.env.JWT_SECRET.length < 24;
if (weak) {
  console.error('FATAL: JWT_SECRET is missing, too short (<24 chars) or still the placeholder. Set a strong value in backend/.env');
  process.exit(1);
}

const app = express();
const origins = (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map((s) => s.trim());

app.use(helmet());
app.use(cors({ origin: origins, credentials: true }));
app.use(express.json({ limit: '100kb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

const limiter = (max, windowMin = 15) =>
  rateLimit({ windowMs: windowMin * 60 * 1000, max, standardHeaders: true, legacyHeaders: false,
    message: { success: false, message: 'Too many requests. Please try again later.' } });

app.get('/api/health', (_req, res) => res.json({ success: true, message: 'TransitCare API is running' }));
app.use('/api/auth', limiter(60), require('./routes/auth'));
app.use('/api/complaints/track', limiter(120));
app.use('/api/complaints', require('./routes/complaints'));
app.use('/api/buses', require('./routes/buses'));
app.use('/api/routes', require('./routes/routesRoutes'));
app.use('/api/users', require('./routes/users'));
app.use('/api/stats', require('./routes/stats'));
app.use('/api/messages', limiter(30), require('./routes/messages'));

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
connectDB()
  .then(() => app.listen(PORT, () => console.log(`TransitCare API listening on http://localhost:${PORT}`)))
  .catch((err) => {
    console.error('Failed to start server:', err.message);
    console.error('Is MongoDB running? Check MONGO_URI in backend/.env');
    process.exit(1);
  });
