import { Routes, Route, Link } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import PublicLayout from './components/PublicLayout';
import DashboardLayout from './components/DashboardLayout';
import ProtectedRoute from './components/ProtectedRoute';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import About from './pages/About';
import Contact from './pages/Contact';
import Track from './pages/Track';
import Buses from './pages/Buses';
import RoutesPage from './pages/Routes';
import Dashboard from './pages/Dashboard';
import ComplaintForm from './pages/ComplaintForm';
import ComplaintDetail from './pages/ComplaintDetail';
import AdminOverview from './pages/admin/AdminOverview';
import AdminComplaints from './pages/admin/AdminComplaints';
import AdminBuses from './pages/admin/AdminBuses';
import AdminRoutes from './pages/admin/AdminRoutes';
import AdminUsers from './pages/admin/AdminUsers';
import AdminMessages from './pages/admin/AdminMessages';

const NotFound = () => (
  <div className="grid min-h-[60vh] place-items-center px-4 text-center">
    <div>
      <p className="font-display text-5xl font-semibold text-teal-500">404</p>
      <p className="mt-2 text-navy-500">This stop is not on our map.</p>
      <Link to="/" className="btn-primary mt-5">Back to home</Link>
    </div>
  </div>
);

export default function App() {
  return (
    <>
      <Toaster position="top-right" toastOptions={{ style: { background: '#0B2545', color: '#fff' }, success: { iconTheme: { primary: '#2DC4BC', secondary: '#fff' } } }} />
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/track" element={<Track />} />
          <Route path="/track/:id" element={<Track />} />
          <Route path="/buses" element={<Buses />} />
          <Route path="/routes" element={<RoutesPage />} />
          <Route path="*" element={<NotFound />} />
        </Route>

        <Route element={<ProtectedRoute role="passenger" />}>
          <Route element={<DashboardLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/dashboard/new" element={<ComplaintForm />} />
            <Route path="/dashboard/complaints/:id" element={<ComplaintDetail />} />
            <Route path="/dashboard/complaints/:id/edit" element={<ComplaintForm />} />
          </Route>
        </Route>

        <Route element={<ProtectedRoute role="admin" />}>
          <Route element={<DashboardLayout />}>
            <Route path="/admin" element={<AdminOverview />} />
            <Route path="/admin/complaints" element={<AdminComplaints />} />
            <Route path="/admin/complaints/:id" element={<ComplaintDetail />} />
            <Route path="/admin/buses" element={<AdminBuses />} />
            <Route path="/admin/routes" element={<AdminRoutes />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/messages" element={<AdminMessages />} />
          </Route>
        </Route>
      </Routes>
    </>
  );
}
