import { Search } from 'lucide-react';
import { CATEGORIES, STATUSES, PRIORITIES } from '../utils/constants';

export default function ComplaintFilters({ filters, onChange, showPriority = true }) {
  const set = (k) => (e) => onChange({ ...filters, [k]: e.target.value, page: 1 });
  return (
    <div className="grid gap-3 border-b border-navy-100 p-4 sm:grid-cols-2 lg:grid-cols-5">
      <div className="relative lg:col-span-2">
        <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-navy-200" />
        <input className="input pl-9" placeholder="Search ID, bus number, location or text" value={filters.q || ''} onChange={set('q')} aria-label="Search complaints" />
      </div>
      <select className="input" value={filters.status || ''} onChange={set('status')} aria-label="Filter by status">
        <option value="">All statuses</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}
      </select>
      <select className="input" value={filters.category || ''} onChange={set('category')} aria-label="Filter by category">
        <option value="">All categories</option>{CATEGORIES.map((s) => <option key={s}>{s}</option>)}
      </select>
      {showPriority && (
        <select className="input" value={filters.priority || ''} onChange={set('priority')} aria-label="Filter by priority">
          <option value="">All priorities</option>{PRIORITIES.map((s) => <option key={s}>{s}</option>)}
        </select>
      )}
    </div>
  );
}
