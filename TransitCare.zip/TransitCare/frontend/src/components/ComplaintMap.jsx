import { useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import { Link } from 'react-router-dom';
import { MAP_CENTER, STATUS_COLORS, fmtDate } from '../utils/constants';

function Fit({ points }) {
  const map = useMap();
  useEffect(() => {
    if (!points.length) return;
    const b = points.map((p) => [p.lat, p.lng]);
    map.fitBounds(b, { padding: [30, 30], maxZoom: 14 });
  }, [points, map]);
  return null;
}

// points: [{ id, lat, lng, status, category, busNumber, address, createdAt, link? }]
export default function ComplaintMap({ points = [], height = 'h-96' }) {
  const valid = points.filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng));
  return (
    <div className={`${height} w-full overflow-hidden rounded-xl border border-navy-100`}>
      <MapContainer center={MAP_CENTER} zoom={11} scrollWheelZoom={false} className="h-full w-full">
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Fit points={valid} />
        {valid.map((p) => (
          <CircleMarker key={p.id} center={[p.lat, p.lng]} radius={8} pathOptions={{ color: '#fff', weight: 2, fillColor: STATUS_COLORS[p.status] || '#13315C', fillOpacity: 0.95 }}>
            <Popup>
              <div className="text-sm">
                <p className="font-semibold">{p.category}</p>
                <p className="text-navy-500">{p.id} {p.busNumber ? `- ${p.busNumber}` : ''}</p>
                {p.address && <p>{p.address}</p>}
                <p style={{ color: STATUS_COLORS[p.status] }} className="font-semibold">{p.status} - {fmtDate(p.createdAt)}</p>
                {p.link && <Link to={p.link} className="font-semibold text-teal-600 underline">View details</Link>}
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}

export const MapLegend = () => (
  <div className="mt-2 flex flex-wrap gap-4 text-xs text-navy-500">
    {Object.entries(STATUS_COLORS).map(([s, c]) => (
      <span key={s} className="inline-flex items-center gap-1.5"><span className="h-3 w-3 rounded-full" style={{ background: c }} />{s}</span>
    ))}
  </div>
);
