import { Link } from 'react-router-dom';
import { Eye, Pencil, Trash2, RefreshCw } from 'lucide-react';
import { StatusBadge, PriorityBadge, EmptyState } from './ui';
import { fmtDate } from '../utils/constants';

// basePath: '/dashboard' or '/admin'; admin gets passenger column + status action
export default function ComplaintTable({ complaints, basePath, admin, onStatus, onDelete }) {
  if (!complaints.length) return <EmptyState title="No complaints found" text="Try changing the filters or search text." />;
  const detail = (c) => `${basePath}/complaints/${c._id}`;
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-navy-100">
        <thead className="bg-mist">
          <tr>
            <th className="th">Complaint ID</th>{admin && <th className="th">Passenger</th>}
            <th className="th">Bus / Route</th><th className="th">Category</th><th className="th">Location</th>
            <th className="th">Priority</th><th className="th">Status</th><th className="th">Updated</th><th className="th text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-navy-50">
          {complaints.map((c) => (
            <tr key={c._id} className="hover:bg-mist/60">
              <td className="td font-semibold text-navy-700"><Link to={detail(c)} className="hover:text-teal-600">{c.complaintId}</Link><div className="text-xs font-normal text-navy-500">{fmtDate(c.createdAt)}</div></td>
              {admin && <td className="td">{c.passenger?.name || '-'}<div className="text-xs text-navy-500">{c.passenger?.email}</div></td>}
              <td className="td">{c.busNumber}<div className="text-xs text-navy-500">Route {c.route?.routeNumber}</div></td>
              <td className="td">{c.category}</td>
              <td className="td max-w-[14rem] truncate" title={c.location?.address}>{c.location?.address}</td>
              <td className="td"><PriorityBadge priority={c.priority} /></td>
              <td className="td"><StatusBadge status={c.status} /></td>
              <td className="td whitespace-nowrap text-navy-500">{fmtDate(c.updatedAt)}</td>
              <td className="td">
                <div className="flex justify-end gap-1">
                  <Link to={detail(c)} className="btn-outline btn-sm" title="View"><Eye className="h-3.5 w-3.5" /></Link>
                  {admin && <button className="btn-outline btn-sm" title="Update status" onClick={() => onStatus(c)}><RefreshCw className="h-3.5 w-3.5" /></button>}
                  {!admin && c.status === 'Pending' && <Link to={`${detail(c)}/edit`} className="btn-outline btn-sm" title="Edit"><Pencil className="h-3.5 w-3.5" /></Link>}
                  {(admin || c.status === 'Pending') && onDelete && (
                    <button className="btn-outline btn-sm text-red-600" title="Delete" onClick={() => onDelete(c)}><Trash2 className="h-3.5 w-3.5" /></button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
