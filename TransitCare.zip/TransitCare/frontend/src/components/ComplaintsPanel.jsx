import { useState } from 'react';
import toast from 'react-hot-toast';
import { Table, Map as MapIcon } from 'lucide-react';
import api, { errMsg } from '../api/client';
import useFetch from '../hooks/useFetch';
import ComplaintFilters from './ComplaintFilters';
import ComplaintTable from './ComplaintTable';
import ComplaintMap, { MapLegend } from './ComplaintMap';
import StatusModal from './StatusModal';
import ConfirmModal from './ConfirmModal';
import { Pagination, Spinner, ErrorBox } from './ui';

// Used by the passenger dashboard (own complaints) and the admin complaints page (all complaints).
export default function ComplaintsPanel({ admin = false, onChanged }) {
  const [filters, setFilters] = useState({ q: '', status: '', category: '', priority: '', page: 1 });
  const [view, setView] = useState('table');
  const [statusFor, setStatusFor] = useState(null);
  const [deleteFor, setDeleteFor] = useState(null);
  const basePath = admin ? '/admin' : '/dashboard';
  const mapView = view === 'map';

  const { body, loading, error, reload } = useFetch(
    () => api.get('/complaints', { params: { ...filters, limit: mapView ? 200 : 10, page: mapView ? 1 : filters.page } }).then((r) => r.data),
    [JSON.stringify(filters), view]
  );
  const rows = body?.data || [];
  const refresh = () => { reload(); onChanged && onChanged(); };

  const remove = async () => {
    try {
      const { data } = await api.delete(`/complaints/${deleteFor._id}`);
      toast.success(data.message);
      setDeleteFor(null);
      refresh();
    } catch (e) { toast.error(errMsg(e)); }
  };

  const points = rows.map((c) => ({
    id: c.complaintId, lat: c.location?.lat, lng: c.location?.lng, status: c.status, category: c.category,
    busNumber: c.busNumber, address: c.location?.address, createdAt: c.createdAt, link: `${basePath}/complaints/${c._id}`,
  }));

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between border-b border-navy-100 px-4 py-3">
        <h2 className="font-display text-lg font-semibold">{admin ? 'All complaints' : 'My complaints'}</h2>
        <div className="inline-flex rounded-lg border border-navy-200 p-0.5">
          <button className={`btn btn-sm ${!mapView ? 'bg-navy-800 text-white' : 'text-navy-700'}`} onClick={() => setView('table')}><Table className="h-3.5 w-3.5" /> Table</button>
          <button className={`btn btn-sm ${mapView ? 'bg-navy-800 text-white' : 'text-navy-700'}`} onClick={() => setView('map')}><MapIcon className="h-3.5 w-3.5" /> Map</button>
        </div>
      </div>
      <ComplaintFilters filters={filters} onChange={setFilters} />
      {loading ? <Spinner /> : error ? <div className="p-4"><ErrorBox message={error} onRetry={reload} /></div> : mapView ? (
        <div className="p-4"><ComplaintMap points={points} height="h-[28rem]" /><MapLegend />
          <p className="mt-2 text-xs text-navy-500">Showing {points.filter((p) => p.lat).length} of {rows.length} complaints that have a map location.</p></div>
      ) : (
        <>
          <ComplaintTable complaints={rows} basePath={basePath} admin={admin} onStatus={setStatusFor} onDelete={setDeleteFor} />
          <Pagination pagination={body.pagination} onPage={(page) => setFilters({ ...filters, page })} />
        </>
      )}
      {statusFor && <StatusModal complaint={statusFor} onClose={() => setStatusFor(null)} onSaved={() => { setStatusFor(null); refresh(); }} />}
      {deleteFor && <ConfirmModal title="Delete complaint?" message={`Complaint ${deleteFor.complaintId} will be permanently removed.`} onConfirm={remove} onClose={() => setDeleteFor(null)} />}
    </div>
  );
}
