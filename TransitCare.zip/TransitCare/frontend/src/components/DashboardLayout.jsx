import { useState } from 'react';
import { NavLink, Outlet, Link, useNavigate } from 'react-router-dom';
import { LayoutDashboard, PlusCircle, ClipboardList, Search, Bus, Route as RouteIcon, Users, Mail, LogOut, Menu, X, Home } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '../context/AuthContext';

const passengerLinks = [
  ['/dashboard', 'My complaints', LayoutDashboard, true], ['/dashboard/new', 'Report complaint', PlusCircle], ['/track', 'Track by ID', Search],
  ['/routes', 'Routes', RouteIcon], ['/buses', 'Buses', Bus],
];
const adminLinks = [
  ['/admin', 'Overview', LayoutDashboard, true], ['/admin/complaints', 'Complaints', ClipboardList], ['/admin/buses', 'Buses', Bus],
  ['/admin/routes', 'Routes', RouteIcon], ['/admin/users', 'Users', Users], ['/admin/messages', 'Messages', Mail],
];

export default function DashboardLayout() {
  const { user, isAdmin, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const links = isAdmin ? adminLinks : passengerLinks;

  const item = ({ isActive }) =>
    `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${isActive ? 'bg-teal-500 text-white' : 'text-navy-100 hover:bg-white/10 hover:text-white'}`;

  const sidebar = (
    <div className="flex h-full flex-col bg-navy-800 p-4">
      <div className="mb-6 hidden px-1 lg:block"><Logo light to="/" /></div>
      <p className="mb-2 px-3 text-xs text-navy-200">{isAdmin ? 'Administration' : 'Passenger'}</p>
      <nav className="flex-1 space-y-1" onClick={() => setOpen(false)}>
        {links.map(([to, label, Icon, end]) => (
          <NavLink key={to} to={to} end={end} className={item}><Icon className="h-4 w-4" /> {label}</NavLink>
        ))}
      </nav>
      <div className="mt-4 border-t border-white/10 pt-4">
        <div className="mb-3 px-3">
          <p className="truncate text-sm font-semibold text-white">{user.name}</p>
          <p className="truncate text-xs text-navy-200">{user.email}</p>
        </div>
        <Link to="/" className={item({ isActive: false })}><Home className="h-4 w-4" /> Public site</Link>
        <button className={`${item({ isActive: false })} w-full`} onClick={() => { logout(); navigate('/'); }}><LogOut className="h-4 w-4" /> Log out</button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:flex">
      <aside className="fixed inset-y-0 left-0 hidden w-64 lg:block">{sidebar}</aside>
      <div className="sticky top-0 z-40 flex h-14 items-center justify-between bg-navy-800 px-4 lg:hidden">
        <Logo light />
        <button className="p-2 text-white" onClick={() => setOpen(!open)} aria-label="Toggle sidebar">{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <div className="fixed inset-0 z-30 pt-14 lg:hidden">
          <div className="absolute inset-0 bg-navy-900/60" onClick={() => setOpen(false)} />
          <div className="relative h-full w-72 max-w-[85%]">{sidebar}</div>
        </div>
      )}
      <main className="min-w-0 flex-1 p-4 sm:p-6 lg:ml-64 lg:p-8"><Outlet /></main>
    </div>
  );
}
