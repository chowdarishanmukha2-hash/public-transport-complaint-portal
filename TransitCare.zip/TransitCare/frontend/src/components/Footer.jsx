import { Link } from 'react-router-dom';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="bg-navy-900 text-navy-100">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-3">
        <div>
          <Logo light />
          <p className="mt-3 max-w-xs text-sm text-navy-200">A shared channel between bus passengers and transport authorities. Report an issue, follow it to resolution.</p>
        </div>
        <div className="text-sm">
          <p className="mb-2 font-display font-semibold text-white">Passengers</p>
          <ul className="space-y-1.5">
            <li><Link to="/dashboard/new" className="hover:text-white">Report a complaint</Link></li>
            <li><Link to="/track" className="hover:text-white">Track a complaint</Link></li>
            <li><Link to="/routes" className="hover:text-white">Route information</Link></li>
            <li><Link to="/buses" className="hover:text-white">Bus fleet</Link></li>
          </ul>
        </div>
        <div className="text-sm">
          <p className="mb-2 font-display font-semibold text-white">TransitCare</p>
          <ul className="space-y-1.5">
            <li><Link to="/about" className="hover:text-white">About</Link></li>
            <li><Link to="/contact" className="hover:text-white">Contact us</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-navy-200">&copy; {new Date().getFullYear()} TransitCare. Built for hackathon demonstration.</div>
    </footer>
  );
}
