import { MapContainer, TileLayer, CircleMarker, useMapEvents, useMap } from 'react-leaflet';
import { useEffect } from 'react';
import { MAP_CENTER } from '../utils/constants';

function Clicker({ onPick }) {
  useMapEvents({ click: (e) => onPick(e.latlng.lat, e.latlng.lng) });
  return null;
}
function Recenter({ value }) {
  const map = useMap();
  useEffect(() => { if (value?.lat && value?.lng) map.setView([value.lat, value.lng], Math.max(map.getZoom(), 14)); }, [value?.lat, value?.lng]); // eslint-disable-line
  return null;
}

export default function LocationPicker({ value, onPick }) {
  const has = Number.isFinite(value?.lat) && Number.isFinite(value?.lng);
  return (
    <div className="h-64 overflow-hidden rounded-lg border border-navy-200">
      <MapContainer center={has ? [value.lat, value.lng] : MAP_CENTER} zoom={has ? 14 : 11} className="h-full w-full">
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Clicker onPick={onPick} />
        <Recenter value={value} />
        {has && <CircleMarker center={[value.lat, value.lng]} radius={9} pathOptions={{ color: '#fff', weight: 3, fillColor: '#12A8A0', fillOpacity: 1 }} />}
      </MapContainer>
    </div>
  );
}
