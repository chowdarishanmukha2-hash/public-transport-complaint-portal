import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';
import { useAuth } from '../context/AuthContext';

const links = [
  ['/', 'Home'], ['/track', 'Track complaint'], ['/buses', 'Buses'], ['/routes', 'Routes'], ['/about', 'About'], ['/contact', 'Contact'],
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { user, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const cls = ({ isActive }) => `rounded-md px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-white/10 text-white' : 'text-navy-100 hover:text-white'}`;

  return (
    <header className="sticky top-0 z-40 bg-navy-800 shadow">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <Logo light />
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={cls}>{label}</NavLink>)}
        </nav>
        <div className="hidden items-center gap-2 lg:flex">
          {user ? (
            <>
              <Link to={isAdmin ? '/admin' : '/dashboard'} className="btn-primary btn-sm">{isAdmin ? 'Admin dashboard' : 'My dashboard'}</Link>
              <button className="btn btn-sm text-navy-100 hover:text-white" onClick={() => { logout(); navigate('/'); }}>Log out</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn-sm text-white hover:bg-white/10">Log in</Link>
              <Link to="/register" className="btn-primary btn-sm">Sign up</Link>
            </>
          )}
        </div>
        <button className="rounded p-2 text-white lg:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/10 px-4 pb-4 lg:hidden">
          <nav className="flex flex-col py-2" onClick={() => setOpen(false)}>
            {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={cls}>{label}</NavLink>)}
          </nav>
          <div className="flex gap-2" onClick={() => setOpen(false)}>
            {user ? (
              <>
                <Link to={isAdmin ? '/admin' : '/dashboard'} className="btn-primary flex-1">Dashboard</Link>
                <button className="btn flex-1 border border-white/20 text-white" onClick={() => { logout(); navigate('/'); }}>Log out</button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn flex-1 border border-white/20 text-white">Log in</Link>
                <Link to="/register" className="btn-primary flex-1">Sign up</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
