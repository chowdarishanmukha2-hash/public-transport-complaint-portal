import { ClipboardList, Clock, Loader2, CheckCircle2, Percent } from 'lucide-react';
import { StatCard } from './ui';

export default function StatGrid({ s }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
      <StatCard label="Total complaints" value={s.total} icon={ClipboardList} accent="navy" />
      <StatCard label="Pending" value={s.pending} icon={Clock} accent="amber" />
      <StatCard label="In progress" value={s.inProgress} icon={Loader2} accent="blue" />
      <StatCard label="Resolved" value={s.resolved} icon={CheckCircle2} accent="teal" />
      <StatCard label="Resolution rate" value={`${s.resolutionRate}%`} icon={Percent} accent="teal" hint={`${s.rejected} rejected`} />
    </div>
  );
}
