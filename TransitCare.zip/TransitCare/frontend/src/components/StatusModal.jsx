import { useState } from 'react';
import toast from 'react-hot-toast';
import api, { errMsg } from '../api/client';
import { Modal } from './ui';
import { STATUSES, PRIORITIES } from '../utils/constants';

export default function StatusModal({ complaint, onClose, onSaved }) {
  const [status, setStatus] = useState(complaint.status);
  const [priority, setPriority] = useState(complaint.priority);
  const [adminRemarks, setRemarks] = useState(complaint.adminRemarks || '');
  const [saving, setSaving] = useState(false);

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await api.patch(`/complaints/${complaint._id}/status`, { status, priority, adminRemarks });
      toast.success(data.message);
      onSaved(data.data);
    } catch (err) { toast.error(errMsg(err)); } finally { setSaving(false); }
  };

  return (
    <Modal title={`Update ${complaint.complaintId}`} onClose={onClose}>
      <form onSubmit={save} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label">Status</label>
            <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
          <div><label className="label">Priority</label>
            <select className="input" value={priority} onChange={(e) => setPriority(e.target.value)}>{PRIORITIES.map((s) => <option key={s}>{s}</option>)}</select></div>
        </div>
        <div><label className="label">Remarks visible to the passenger</label>
          <textarea className="input min-h-[96px]" maxLength={1000} value={adminRemarks} onChange={(e) => setRemarks(e.target.value)} placeholder="What action was taken?" /></div>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-outline" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save changes'}</button>
        </div>
      </form>
    </Modal>
  );
}
