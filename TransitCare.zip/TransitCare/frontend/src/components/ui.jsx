import { Loader2, Inbox, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { useEffect } from 'react';

export const Spinner = ({ label = 'Loading...', className = '' }) => (
  <div className={`flex items-center justify-center gap-2 py-12 text-sm text-navy-500 ${className}`} role="status">
    <Loader2 className="h-5 w-5 animate-spin text-teal-500" /> {label}
  </div>
);

const STATUS_STYLE = {
  Pending: 'bg-amber-50 text-amber-700 ring-amber-200',
  'In Progress': 'bg-blue-50 text-blue-700 ring-blue-200',
  Resolved: 'bg-teal-50 text-teal-700 ring-teal-200',
  Rejected: 'bg-red-50 text-red-700 ring-red-200',
  Active: 'bg-teal-50 text-teal-700 ring-teal-200',
  Maintenance: 'bg-amber-50 text-amber-700 ring-amber-200',
  Inactive: 'bg-navy-50 text-navy-500 ring-navy-200',
};
export const StatusBadge = ({ status }) => (
  <span className={`inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${STATUS_STYLE[status] || STATUS_STYLE.Inactive}`}>{status}</span>
);

const PRIORITY_STYLE = { Low: 'text-navy-500', Medium: 'text-blue-700', High: 'text-orange-600', Critical: 'text-red-600' };
export const PriorityBadge = ({ priority }) => (
  <span className={`inline-flex items-center gap-1.5 text-xs font-semibold ${PRIORITY_STYLE[priority]}`}>
    <span className="h-2 w-2 rounded-full bg-current" /> {priority}
  </span>
);

export const StatCard = ({ label, value, hint, icon: Icon, accent = 'teal' }) => {
  const colors = { teal: 'bg-teal-50 text-teal-600', amber: 'bg-amber-50 text-amber-600', blue: 'bg-blue-50 text-blue-600', navy: 'bg-navy-50 text-navy-700', red: 'bg-red-50 text-red-600' };
  return (
    <div className="card flex items-center gap-4 p-5">
      {Icon && <div className={`grid h-11 w-11 shrink-0 place-items-center rounded-lg ${colors[accent]}`}><Icon className="h-5 w-5" /></div>}
      <div className="min-w-0">
        <p className="font-display text-2xl font-semibold leading-none">{value ?? '-'}</p>
        <p className="mt-1 text-sm text-navy-500">{label}</p>
        {hint && <p className="text-xs text-navy-200">{hint}</p>}
      </div>
    </div>
  );
};

export const EmptyState = ({ title = 'Nothing here yet', text, action }) => (
  <div className="flex flex-col items-center px-4 py-12 text-center">
    <Inbox className="h-10 w-10 text-navy-200" />
    <p className="mt-3 font-display font-semibold">{title}</p>
    {text && <p className="mt-1 max-w-sm text-sm text-navy-500">{text}</p>}
    {action && <div className="mt-4">{action}</div>}
  </div>
);

export const ErrorBox = ({ message, onRetry }) => (
  <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
    {message} {onRetry && <button onClick={onRetry} className="ml-2 font-semibold underline">Retry</button>}
  </div>
);

export const PageHeader = ({ title, subtitle, actions }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
    <div>
      <h1 className="text-2xl font-semibold">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-navy-500">{subtitle}</p>}
    </div>
    {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
  </div>
);

export function Modal({ title, onClose, children, wide }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-navy-900/60 p-0 sm:items-center sm:p-4" onMouseDown={onClose} role="dialog" aria-modal="true" aria-label={title}>
      <div className={`max-h-[92vh] w-full overflow-y-auto rounded-t-2xl bg-white shadow-xl sm:rounded-2xl ${wide ? 'sm:max-w-2xl' : 'sm:max-w-lg'}`} onMouseDown={(e) => e.stopPropagation()}>
        <div className="sticky top-0 flex items-center justify-between border-b border-navy-100 bg-white px-5 py-4">
          <h2 className="font-display text-lg font-semibold">{title}</h2>
          <button onClick={onClose} className="rounded p-1 hover:bg-navy-50" aria-label="Close"><X className="h-5 w-5" /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export const Pagination = ({ pagination, onPage }) => {
  if (!pagination || pagination.pages <= 1) return null;
  const { page, pages, total } = pagination;
  return (
    <div className="flex items-center justify-between border-t border-navy-100 px-4 py-3 text-sm">
      <span className="text-navy-500">{total} results</span>
      <div className="flex items-center gap-2">
        <button className="btn-outline btn-sm" disabled={page <= 1} onClick={() => onPage(page - 1)}><ChevronLeft className="h-4 w-4" /> Prev</button>
        <span className="px-1">Page {page} of {pages}</span>
        <button className="btn-outline btn-sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>Next <ChevronRight className="h-4 w-4" /></button>
      </div>
    </div>
  );
};

export const Field = ({ label, error, children, hint }) => (
  <div>
    <label className="label">{label}</label>
    {children}
    {hint && !error && <p className="mt-1 text-xs text-navy-500">{hint}</p>}
    {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
  </div>
);
