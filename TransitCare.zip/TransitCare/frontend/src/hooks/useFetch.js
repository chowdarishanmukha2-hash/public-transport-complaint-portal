import { useEffect, useState } from 'react';
import { errMsg } from '../api/client';

// fetcher must return a promise resolving to the response body ({ success, data, ... })
export default function useFetch(fetcher, deps = []) {
  const [state, setState] = useState({ body: null, loading: true, error: null });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    fetcher()
      .then((body) => alive && setState({ body, loading: false, error: null }))
      .catch((e) => alive && setState({ body: null, loading: false, error: errMsg(e) }));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { ...state, data: state.body?.data, reload: () => setTick((t) => t + 1) };
}
