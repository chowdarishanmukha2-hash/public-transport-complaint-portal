import { Link } from 'react-router-dom';
import { ShieldCheck, MapPin, BarChart3, Users } from 'lucide-react';

export default function About() {
  const items = [
    [MapPin, 'Location-aware reports', 'Every complaint can carry a map pin so depots know exactly where the problem happened.'],
    [ShieldCheck, 'Accountable by design', 'Each status change is recorded with remarks, so passengers can see what the authority did.'],
    [BarChart3, 'Data for decisions', 'Dashboards are calculated from live records: categories, busiest routes and resolution rates.'],
    [Users, 'Two roles, one system', 'Passengers file and track. Admins manage complaints, buses, routes and users.'],
  ];
  return (
    <div className="mx-auto max-w-5xl px-4 py-14">
      <h1 className="text-3xl font-semibold">About TransitCare</h1>
      <p className="mt-4 max-w-3xl text-lg text-navy-700">Passengers often notice problems first, but have no simple way to tell the people who can fix them. TransitCare gives every rider a direct line to the transport authority, and gives the authority a clear queue to work through.</p>
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        {items.map(([Icon, t, d]) => (
          <div key={t} className="card flex gap-4 p-5">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-teal-50 text-teal-600"><Icon className="h-5 w-5" /></div>
            <div><h2 className="font-semibold">{t}</h2><p className="mt-1 text-sm text-navy-500">{d}</p></div>
          </div>
        ))}
      </div>
      <div className="card mt-10 p-6">
        <h2 className="text-xl font-semibold">Built with</h2>
        <p className="mt-2 text-sm text-navy-500">React + Vite, Tailwind CSS, React Router, Node.js, Express, MongoDB with Mongoose, JWT authentication with hashed passwords, and Leaflet maps on OpenStreetMap.</p>
        <Link to="/dashboard/new" className="btn-primary mt-5">Report a complaint</Link>
      </div>
    </div>
  );
}
