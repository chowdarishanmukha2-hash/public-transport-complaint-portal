import { useState } from 'react';
import { Search } from 'lucide-react';
import api from '../api/client';
import useFetch from '../hooks/useFetch';
import { Spinner, ErrorBox, StatusBadge, EmptyState } from '../components/ui';
import { BUS_TYPES } from '../utils/constants';

export default function Buses() {
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const { data, loading, error, reload } = useFetch(() => api.get('/buses', { params: { q, type } }).then((r) => r.data), [q, type]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12">
      <h1 className="text-3xl font-semibold">Bus fleet</h1>
      <p className="mt-2 text-navy-500">Find a bus number before you file a complaint.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-3 lg:max-w-2xl">
        <div className="relative sm:col-span-2"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-navy-200" />
          <input className="input pl-9" placeholder="Search bus number or driver" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search buses" /></div>
        <select className="input" value={type} onChange={(e) => setType(e.target.value)} aria-label="Bus type"><option value="">All types</option>{BUS_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
      </div>
      <div className="mt-6">
        {loading ? <Spinner /> : error ? <ErrorBox message={error} onRetry={reload} /> : data.length === 0 ? <div className="card"><EmptyState title="No buses match your search" /></div> : (
          <div className="card overflow-x-auto">
            <table className="min-w-full divide-y divide-navy-100">
              <thead className="bg-mist"><tr><th className="th">Bus number</th><th className="th">Route</th><th className="th">Type</th><th className="th">Capacity</th><th className="th">Driver</th><th className="th">Status</th></tr></thead>
              <tbody className="divide-y divide-navy-50">
                {data.map((b) => (
                  <tr key={b._id}>
                    <td className="td font-semibold">{b.busNumber}</td>
                    <td className="td">{b.route ? `${b.route.routeNumber} - ${b.route.name}` : '-'}</td>
                    <td className="td">{b.type}</td><td className="td">{b.capacity} seats</td><td className="td">{b.driverName || '-'}</td>
                    <td className="td"><StatusBadge status={b.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
