import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ArrowLeft, MapPin, Pencil, RefreshCw, Trash2 } from 'lucide-react';
import api, { errMsg } from '../api/client';
import useFetch from '../hooks/useFetch';
import { StatusBadge, PriorityBadge, Spinner, ErrorBox } from '../components/ui';
import ComplaintMap from '../components/ComplaintMap';
import StatusModal from '../components/StatusModal';
import ConfirmModal from '../components/ConfirmModal';
import { fmtDateTime, STATUS_COLORS } from '../utils/constants';

export default function ComplaintDetail() {
  const { id } = useParams();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const admin = pathname.startsWith('/admin');
  const base = admin ? '/admin' : '/dashboard';
  const { data: c, loading, error, reload } = useFetch(() => api.get(`/complaints/${id}`).then((r) => r.data), [id]);
  const [statusOpen, setStatusOpen] = useState(false);
  const [delOpen, setDelOpen] = useState(false);

  if (loading) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;

  const remove = async () => {
    try { await api.delete(`/complaints/${c._id}`); toast.success('Complaint deleted'); navigate(admin ? '/admin/complaints' : '/dashboard'); }
    catch (e) { toast.error(errMsg(e)); }
  };
  const hasPin = Number.isFinite(c.location?.lat) && Number.isFinite(c.location?.lng);

  return (
    <>
      <Link to={admin ? '/admin/complaints' : '/dashboard'} className="mb-4 inline-flex items-center gap-1 text-sm font-medium text-teal-600"><ArrowLeft className="h-4 w-4" /> Back to complaints</Link>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">{c.complaintId}</h1>
          <p className="mt-1 text-sm text-navy-500">{c.category} on {c.busNumber}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <StatusBadge status={c.status} />
          {admin && <button className="btn-primary btn-sm" onClick={() => setStatusOpen(true)}><RefreshCw className="h-3.5 w-3.5" /> Update status</button>}
          {!admin && c.status === 'Pending' && <Link to={`${base}/complaints/${c._id}/edit`} className="btn-outline btn-sm"><Pencil className="h-3.5 w-3.5" /> Edit</Link>}
          {(admin || c.status === 'Pending') && <button className="btn-outline btn-sm text-red-600" onClick={() => setDelOpen(true)}><Trash2 className="h-3.5 w-3.5" /> Delete</button>}
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <div className="card p-5">
            <h2 className="mb-2 font-display font-semibold">Description</h2>
            <p className="whitespace-pre-wrap text-sm text-navy-700">{c.description}</p>
            {c.imageUrl && <a href={c.imageUrl} target="_blank" rel="noreferrer noopener" className="mt-3 inline-block"><img src={c.imageUrl} alt="Attached evidence" className="max-h-56 rounded-lg border border-navy-100" onError={(e) => { e.currentTarget.style.display = 'none'; }} /></a>}
            {c.adminRemarks && <div className="mt-4 rounded-lg bg-teal-50 p-3 text-sm"><p className="text-xs font-semibold text-teal-700">Authority remarks</p><p className="mt-1">{c.adminRemarks}</p></div>}
          </div>
          {hasPin && (
            <div className="card p-5">
              <h2 className="mb-3 font-display font-semibold">Reported location</h2>
              <ComplaintMap height="h-72" points={[{ id: c.complaintId, lat: c.location.lat, lng: c.location.lng, status: c.status, category: c.category, busNumber: c.busNumber, address: c.location.address, createdAt: c.createdAt }]} />
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="card p-5">
            <dl className="space-y-3 text-sm">
              <div><dt className="text-navy-500">Route</dt><dd className="font-semibold">{c.route ? `${c.route.routeNumber} - ${c.route.name}` : '-'}</dd></div>
              <div><dt className="text-navy-500">Priority</dt><dd><PriorityBadge priority={c.priority} /></dd></div>
              <div><dt className="text-navy-500">Location</dt><dd className="font-semibold"><MapPin className="mr-1 inline h-4 w-4 text-teal-600" />{c.location?.address}</dd></div>
              {admin && c.passenger && <div><dt className="text-navy-500">Passenger</dt><dd className="font-semibold">{c.passenger.name}</dd><dd className="text-navy-500">{c.passenger.email}{c.passenger.phone ? ` - ${c.passenger.phone}` : ''}</dd></div>}
              <div><dt className="text-navy-500">Submitted</dt><dd>{fmtDateTime(c.createdAt)}</dd></div>
              <div><dt className="text-navy-500">Last updated</dt><dd>{fmtDateTime(c.updatedAt)}</dd></div>
            </dl>
          </div>
          <div className="card p-5">
            <h2 className="mb-4 font-display font-semibold">Status history</h2>
            <ol className="relative ml-2 border-l-2 border-navy-100">
              {[...c.statusHistory].reverse().map((h, i) => (
                <li key={i} className="relative pb-4 pl-6 last:pb-0">
                  <span className="absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 border-white" style={{ background: STATUS_COLORS[h.status] }} />
                  <p className="text-sm font-semibold">{h.status}</p>
                  <p className="text-xs text-navy-500">{fmtDateTime(h.at)}</p>
                  {h.note && <p className="mt-0.5 text-sm text-navy-700">{h.note}</p>}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>

      {statusOpen && <StatusModal complaint={c} onClose={() => setStatusOpen(false)} onSaved={() => { setStatusOpen(false); reload(); }} />}
      {delOpen && <ConfirmModal title="Delete complaint?" message={`Complaint ${c.complaintId} will be permanently removed.`} onConfirm={remove} onClose={() => setDelOpen(false)} />}
    </>
  );
}
