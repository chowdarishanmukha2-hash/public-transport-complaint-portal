import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Crosshair, CheckCircle2, Copy } from 'lucide-react';
import api, { errMsg } from '../api/client';
import useFetch from '../hooks/useFetch';
import { Field, PageHeader, Spinner, ErrorBox } from '../components/ui';
import LocationPicker from '../components/LocationPicker';
import { CATEGORIES, PRIORITIES } from '../utils/constants';

const blank = { route: '', busNumber: '', category: '', description: '', priority: 'Medium', address: '', lat: null, lng: null, imageUrl: '' };

export default function ComplaintForm() {
  const { id } = useParams();
  const editing = !!id;
  const navigate = useNavigate();
  const [form, setForm] = useState(blank);
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState(null);
  const [loadingExisting, setLoadingExisting] = useState(editing);

  const routes = useFetch(() => api.get('/routes', { params: { active: true } }).then((r) => r.data));
  const buses = useFetch(() => api.get('/buses', { params: { route: form.route } }).then((r) => r.data), [form.route]);
  const busOptions = useMemo(() => (form.route ? buses.data || [] : []), [form.route, buses.data]);

  useEffect(() => {
    if (!editing) return;
    api.get(`/complaints/${id}`).then(({ data }) => {
      const c = data.data;
      setForm({ route: c.route?._id || '', busNumber: c.busNumber, category: c.category, description: c.description, priority: c.priority,
        address: c.location?.address || '', lat: c.location?.lat ?? null, lng: c.location?.lng ?? null, imageUrl: c.imageUrl || '' });
    }).catch((e) => { toast.error(errMsg(e)); navigate('/dashboard'); }).finally(() => setLoadingExisting(false));
  }, [id]); // eslint-disable-line

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const pick = async (lat, lng) => {
    setForm((f) => ({ ...f, lat: +lat.toFixed(6), lng: +lng.toFixed(6) }));
    if (form.address.trim()) return;
    try { // optional: prefill address using OpenStreetMap Nominatim
      const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`);
      const j = await r.json();
      if (j.display_name) setForm((f) => (f.address.trim() ? f : { ...f, address: j.display_name.split(',').slice(0, 3).join(',').trim() }));
    } catch { /* address can be typed manually */ }
  };

  const locate = () => {
    if (!navigator.geolocation) return toast.error('Location is not supported by this browser.');
    navigator.geolocation.getCurrentPosition((p) => pick(p.coords.latitude, p.coords.longitude), () => toast.error('Could not get your location. Click on the map instead.'));
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!form.route) return toast.error('Select a route');
    if (!form.category) return toast.error('Select a category');
    const payload = {
      route: form.route, busNumber: form.busNumber, category: form.category, description: form.description, priority: form.priority,
      location: { address: form.address, lat: form.lat, lng: form.lng }, imageUrl: form.imageUrl,
    };
    setBusy(true);
    try {
      if (editing) {
        await api.put(`/complaints/${id}`, payload);
        toast.success('Complaint updated');
        navigate(`/dashboard/complaints/${id}`);
      } else {
        const { data } = await api.post('/complaints', payload);
        toast.success(data.message);
        setCreated(data.data);
      }
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };

  if (created) {
    return (
      <div className="mx-auto max-w-lg">
        <div className="card p-8 text-center">
          <CheckCircle2 className="mx-auto h-12 w-12 text-teal-500" />
          <h1 className="mt-3 text-2xl font-semibold">Complaint submitted</h1>
          <p className="mt-1 text-sm text-navy-500">Keep this ID to track progress at any time.</p>
          <div className="my-5 flex items-center justify-center gap-2 rounded-lg bg-mist p-4">
            <span className="font-display text-2xl font-semibold tracking-wide">{created.complaintId}</span>
            <button className="btn-outline btn-sm" onClick={() => { navigator.clipboard?.writeText(created.complaintId); toast.success('ID copied'); }} aria-label="Copy complaint ID"><Copy className="h-3.5 w-3.5" /></button>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            <Link to={`/dashboard/complaints/${created._id}`} className="btn-primary">View complaint</Link>
            <button className="btn-outline" onClick={() => { setCreated(null); setForm(blank); }}>Report another</button>
          </div>
        </div>
      </div>
    );
  }
  if (loadingExisting || routes.loading) return <Spinner />;
  if (routes.error) return <ErrorBox message={routes.error} onRetry={routes.reload} />;

  return (
    <>
      <PageHeader title={editing ? 'Edit complaint' : 'Report a complaint'} subtitle={editing ? 'You can edit while the complaint is still pending.' : 'Describe what happened. The more specific, the faster it can be resolved.'} />
      <form onSubmit={submit} className="grid gap-6 xl:grid-cols-2">
        <div className="card space-y-4 p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Route">
              <select className="input" required value={form.route} onChange={(e) => setForm({ ...form, route: e.target.value, busNumber: '' })}>
                <option value="">Select route</option>
                {routes.data.map((r) => <option key={r._id} value={r._id}>{r.routeNumber} - {r.name}</option>)}
              </select>
            </Field>
            <Field label="Bus number" hint={form.route ? 'Pick from the list or type the number on the bus' : 'Select a route first'}>
              <input className="input" required list="bus-options" value={form.busNumber} onChange={set('busNumber')} placeholder="TSB-1001" disabled={!form.route} />
              <datalist id="bus-options">{busOptions.map((b) => <option key={b._id} value={b.busNumber}>{b.type}</option>)}</datalist>
            </Field>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Category">
              <select className="input" required value={form.category} onChange={set('category')}><option value="">Select category</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
            </Field>
            <Field label="Priority" hint="How urgent is this for you? The authority may adjust it.">
              <select className="input" value={form.priority} onChange={set('priority')}>{PRIORITIES.map((p) => <option key={p}>{p}</option>)}</select>
            </Field>
          </div>
          <Field label="Description" hint="At least 10 characters">
            <textarea className="input min-h-[130px]" required minLength={10} maxLength={2000} value={form.description} onChange={set('description')} placeholder="What happened, when, and who was affected?" />
          </Field>
          <Field label="Photo link (optional)" hint="Paste a link to an image hosted online">
            <input type="url" className="input" value={form.imageUrl} onChange={set('imageUrl')} placeholder="https://..." />
          </Field>
        </div>

        <div className="card space-y-4 p-5">
          <Field label="Location" hint="Describe the stop or landmark">
            <input className="input" required minLength={3} value={form.address} onChange={set('address')} placeholder="e.g. Ameerpet metro bus stop" />
          </Field>
          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="label !mb-0">Pin on map (optional)</span>
              <button type="button" className="btn-outline btn-sm" onClick={locate}><Crosshair className="h-3.5 w-3.5" /> Use my location</button>
            </div>
            <LocationPicker value={{ lat: form.lat, lng: form.lng }} onPick={pick} />
            <p className="mt-1 text-xs text-navy-500">{form.lat ? `Pinned at ${form.lat}, ${form.lng}` : 'Click the map to drop a pin.'}</p>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Link to="/dashboard" className="btn-outline">Cancel</Link>
            <button className="btn-primary" disabled={busy}>{busy ? 'Submitting...' : editing ? 'Save changes' : 'Submit complaint'}</button>
          </div>
        </div>
      </form>
    </>
  );
}
