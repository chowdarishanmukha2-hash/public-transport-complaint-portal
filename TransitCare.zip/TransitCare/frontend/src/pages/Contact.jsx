import { useState } from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';
import toast from 'react-hot-toast';
import api, { errMsg } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { Field } from '../components/ui';

export default function Contact() {
  const { user } = useAuth();
  const [form, setForm] = useState({ name: user?.name || '', email: user?.email || '', subject: '', message: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { data } = await api.post('/messages', form);
      toast.success(data.message);
      setForm({ ...form, subject: '', message: '' });
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto grid max-w-5xl gap-8 px-4 py-14 md:grid-cols-5">
      <div className="md:col-span-2">
        <h1 className="text-3xl font-semibold">Contact us</h1>
        <p className="mt-3 text-navy-500">Questions about the portal, suggestions for a route, or feedback for the team? Send us a message.</p>
        <ul className="mt-6 space-y-4 text-sm">
          <li className="flex gap-3"><Mail className="h-5 w-5 text-teal-600" /> support@transitcare.example</li>
          <li className="flex gap-3"><Phone className="h-5 w-5 text-teal-600" /> 1800-000-1234 (toll free, 6 AM - 10 PM)</li>
          <li className="flex gap-3"><MapPin className="h-5 w-5 text-teal-600" /> TransitCare Control Room, Central Bus Depot, Hyderabad</li>
        </ul>
      </div>
      <form onSubmit={submit} className="card space-y-4 p-6 md:col-span-3">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Your name"><input className="input" required value={form.name} onChange={set('name')} /></Field>
          <Field label="Email"><input type="email" className="input" required value={form.email} onChange={set('email')} /></Field>
        </div>
        <Field label="Subject"><input className="input" required minLength={3} maxLength={120} value={form.subject} onChange={set('subject')} /></Field>
        <Field label="Message" hint="At least 10 characters"><textarea className="input min-h-[140px]" required minLength={10} maxLength={2000} value={form.message} onChange={set('message')} /></Field>
        <button className="btn-primary" disabled={busy}>{busy ? 'Sending...' : 'Send message'}</button>
      </form>
    </div>
  );
}
