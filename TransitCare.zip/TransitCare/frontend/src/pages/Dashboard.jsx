import { Link } from 'react-router-dom';
import { PlusCircle } from 'lucide-react';
import api from '../api/client';
import useFetch from '../hooks/useFetch';
import { useAuth } from '../context/AuthContext';
import { PageHeader, Spinner, ErrorBox } from '../components/ui';
import StatGrid from '../components/StatGrid';
import ComplaintsPanel from '../components/ComplaintsPanel';

export default function Dashboard() {
  const { user } = useAuth();
  const stats = useFetch(() => api.get('/stats/me').then((r) => r.data));
  return (
    <>
      <PageHeader title={`Hello, ${user.name.split(' ')[0]}`} subtitle="Here is where your complaints stand."
        actions={<Link to="/dashboard/new" className="btn-primary"><PlusCircle className="h-4 w-4" /> New complaint</Link>} />
      <div className="mb-6">{stats.loading ? <Spinner /> : stats.error ? <ErrorBox message={stats.error} onRetry={stats.reload} /> : <StatGrid s={stats.data} />}</div>
      <ComplaintsPanel onChanged={stats.reload} />
    </>
  );
}
