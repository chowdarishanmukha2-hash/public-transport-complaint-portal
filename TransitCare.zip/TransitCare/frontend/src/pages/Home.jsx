import { Link } from 'react-router-dom';
import { ClipboardList, Clock, Loader2, CheckCircle2, Percent, Bus, MapPin, Send, Search, Wrench } from 'lucide-react';
import api from '../api/client';
import useFetch from '../hooks/useFetch';
import { StatCard, Spinner, StatusBadge } from '../components/ui';
import ComplaintMap, { MapLegend } from '../components/ComplaintMap';
import { timeAgo, STATUS_COLORS } from '../utils/constants';

export default function Home() {
  const stats = useFetch(() => api.get('/stats').then((r) => r.data));
  const map = useFetch(() => api.get('/complaints/public/map').then((r) => r.data));
  const s = stats.data;
  const recent = (map.data || []).slice(0, 5);
  const points = (map.data || []).map((c) => ({ id: c.complaintId, lat: c.location?.lat, lng: c.location?.lng, status: c.status, category: c.category, busNumber: c.busNumber, address: c.location?.address, createdAt: c.createdAt }));

  return (
    <>
      {/* Hero */}
      <section className="bg-navy-800 text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 lg:grid-cols-2 lg:py-20">
          <div>
            <h1 className="text-4xl font-semibold leading-tight sm:text-5xl">Tell the transport authority what went wrong on your bus.</h1>
            <p className="mt-5 max-w-xl text-lg text-navy-100">Report delays, crowding, damaged buses or rude behaviour in under two minutes, drop a pin on the map and follow your complaint until it is resolved.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/dashboard/new" className="btn-primary px-6 py-3 text-base">Report a complaint</Link>
              <Link to="/track" className="btn border border-white/30 px-6 py-3 text-base text-white hover:bg-white/10">Track a complaint</Link>
            </div>
          </div>

          {/* Live feed styled as a route line */}
          <div className="rounded-2xl bg-white/5 p-5 ring-1 ring-white/10">
            <p className="mb-4 font-display text-sm font-semibold text-teal-200">Latest reports from passengers</p>
            {map.loading ? <Spinner className="text-navy-100" /> : recent.length === 0 ? (
              <p className="py-6 text-sm text-navy-100">No complaints yet. Be the first to report an issue.</p>
            ) : (
              <ol className="relative ml-2 border-l-2 border-teal-500/60">
                {recent.map((c) => (
                  <li key={c._id} className="relative pb-5 pl-6 last:pb-0">
                    <span className="absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 border-navy-800" style={{ background: STATUS_COLORS[c.status] }} />
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="text-sm font-semibold">{c.category} <span className="font-normal text-navy-200">on {c.busNumber}</span></p>
                      <span className="text-xs text-navy-200">{timeAgo(c.createdAt)}</span>
                    </div>
                    <p className="mt-0.5 text-xs text-navy-100"><MapPin className="mr-1 inline h-3 w-3" />{c.location?.address}</p>
                    <div className="mt-1.5"><StatusBadge status={c.status} /></div>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto -mt-0 max-w-7xl px-4 py-10">
        {stats.loading ? <Spinner /> : stats.error ? null : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <StatCard label="Total complaints" value={s.total} icon={ClipboardList} accent="navy" />
            <StatCard label="Pending" value={s.pending} icon={Clock} accent="amber" />
            <StatCard label="In progress" value={s.inProgress} icon={Loader2} accent="blue" />
            <StatCard label="Resolved" value={s.resolved} icon={CheckCircle2} accent="teal" />
            <StatCard label="Resolution rate" value={`${s.resolutionRate}%`} icon={Percent} accent="teal" hint={`${s.buses} buses on ${s.routes} routes`} />
          </div>
        )}
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-7xl px-4 pb-12">
        <h2 className="text-2xl font-semibold">How a complaint travels</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {[
            [Send, '1. Report', 'Pick the route and bus, choose a category, describe the issue and mark the location on the map.'],
            [Wrench, '2. Authority acts', 'Admins review the complaint, set a priority and move it to In Progress with remarks.'],
            [Search, '3. Track', 'Use your unique complaint ID on the tracking page to see every status change.'],
          ].map(([Icon, title, text]) => (
            <div key={title} className="card p-6">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-teal-50 text-teal-600"><Icon className="h-5 w-5" /></div>
              <h3 className="mt-4 text-lg font-semibold">{title}</h3>
              <p className="mt-1 text-sm text-navy-500">{text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Map */}
      <section className="mx-auto max-w-7xl px-4 pb-14">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="text-2xl font-semibold">Where problems are being reported</h2>
            <p className="text-sm text-navy-500">Anonymous community map. Personal details are never shown.</p>
          </div>
          <Link to="/routes" className="btn-outline"><Bus className="h-4 w-4" /> Browse routes</Link>
        </div>
        {map.loading ? <Spinner /> : <><ComplaintMap points={points} height="h-[22rem] sm:h-[28rem]" /><MapLegend /></>}
      </section>

      <section className="bg-teal-50">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-4 px-4 py-10 text-center">
          <h2 className="text-2xl font-semibold">Saw a problem on your commute?</h2>
          <Link to="/dashboard/new" className="btn-navy px-6 py-3 text-base">Report a complaint</Link>
        </div>
      </section>
    </>
  );
}
