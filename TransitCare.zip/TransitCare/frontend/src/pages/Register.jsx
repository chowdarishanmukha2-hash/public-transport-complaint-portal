import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../api/client';
import { Field } from '../components/ui';

export default function Register() {
  const { user, register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  if (user) return <Navigate to={user.role === 'admin' ? '/admin' : '/dashboard'} replace />;

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    const er = {};
    if (form.name.trim().length < 2) er.name = 'Enter your full name';
    if (form.password.length < 8 || !/[A-Za-z]/.test(form.password) || !/\d/.test(form.password)) er.password = 'Use 8+ characters with a letter and a number';
    if (form.password !== form.confirm) er.confirm = 'Passwords do not match';
    setErrors(er);
    if (Object.keys(er).length) return;
    setBusy(true);
    try {
      const { confirm, ...payload } = form; // eslint-disable-line no-unused-vars
      await register(payload);
      toast.success('Account created. You can report a complaint now.');
      navigate('/dashboard');
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto max-w-md px-4 py-14">
      <div className="card p-6 sm:p-8">
        <h1 className="text-2xl font-semibold">Create your account</h1>
        <p className="mt-1 text-sm text-navy-500">Passenger accounts can file and track complaints.</p>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <Field label="Full name" error={errors.name}><input className="input" required value={form.name} onChange={set('name')} autoComplete="name" /></Field>
          <Field label="Email"><input type="email" className="input" required value={form.email} onChange={set('email')} autoComplete="email" /></Field>
          <Field label="Phone (optional)"><input className="input" value={form.phone} onChange={set('phone')} autoComplete="tel" placeholder="9876543210" /></Field>
          <Field label="Password" error={errors.password}><input type="password" className="input" required value={form.password} onChange={set('password')} autoComplete="new-password" /></Field>
          <Field label="Confirm password" error={errors.confirm}><input type="password" className="input" required value={form.confirm} onChange={set('confirm')} autoComplete="new-password" /></Field>
          <button className="btn-primary w-full" disabled={busy}>{busy ? 'Creating account...' : 'Create account'}</button>
        </form>
        <p className="mt-5 text-center text-sm text-navy-500">Already registered? <Link to="/login" className="font-semibold text-teal-600">Log in</Link></p>
      </div>
    </div>
  );
}
