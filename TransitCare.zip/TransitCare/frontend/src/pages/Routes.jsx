import { useState } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { MapContainer, TileLayer, Polyline, CircleMarker, Tooltip, useMap } from 'react-leaflet';
import { useEffect } from 'react';
import api from '../api/client';
import useFetch from '../hooks/useFetch';
import { Spinner, ErrorBox, EmptyState, StatusBadge } from '../components/ui';
import { MAP_CENTER } from '../utils/constants';

function Fit({ pts }) {
  const map = useMap();
  useEffect(() => { if (pts.length) map.fitBounds(pts, { padding: [25, 25] }); }, [pts, map]);
  return null;
}

export function RouteMap({ stops }) {
  const pts = stops.filter((s) => s.lat && s.lng).map((s) => [s.lat, s.lng]);
  return (
    <div className="h-72 overflow-hidden rounded-lg border border-navy-100">
      <MapContainer center={MAP_CENTER} zoom={11} scrollWheelZoom={false} className="h-full w-full">
        <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <Fit pts={pts} />
        <Polyline positions={pts} pathOptions={{ color: '#12A8A0', weight: 4 }} />
        {stops.filter((s) => s.lat && s.lng).map((s) => (
          <CircleMarker key={s.name} center={[s.lat, s.lng]} radius={6} pathOptions={{ color: '#0B2545', weight: 2, fillColor: '#fff', fillOpacity: 1 }}><Tooltip>{s.name}</Tooltip></CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}

export default function RoutesPage() {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(null);
  const { data, loading, error, reload } = useFetch(() => api.get('/routes', { params: { q } }).then((r) => r.data), [q]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      <h1 className="text-3xl font-semibold">Routes and stops</h1>
      <p className="mt-2 text-navy-500">Timings, frequency and stop lists for every route.</p>
      <div className="relative mt-6 lg:max-w-md"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-navy-200" />
        <input className="input pl-9" placeholder="Search route number, name or stop" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search routes" /></div>
      <div className="mt-6 space-y-3">
        {loading ? <Spinner /> : error ? <ErrorBox message={error} onRetry={reload} /> : data.length === 0 ? <div className="card"><EmptyState title="No routes found" /></div> : data.map((r) => {
          const isOpen = open === r._id;
          return (
            <div key={r._id} className="card overflow-hidden">
              <button className="flex w-full items-center gap-4 p-4 text-left" onClick={() => setOpen(isOpen ? null : r._id)} aria-expanded={isOpen}>
                <span className="grid h-12 min-w-[3.5rem] place-items-center rounded-lg bg-navy-800 px-2 font-display text-lg font-semibold text-white">{r.routeNumber}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-semibold">{r.name}</span>
                  <span className="block text-sm text-navy-500">{r.distanceKm} km - every {r.frequencyMins} min - {r.firstBus} to {r.lastBus}</span>
                </span>
                <StatusBadge status={r.active ? 'Active' : 'Inactive'} />
                <ChevronDown className={`h-5 w-5 transition ${isOpen ? 'rotate-180' : ''}`} />
              </button>
              {isOpen && (
                <div className="grid gap-4 border-t border-navy-100 p-4 md:grid-cols-2">
                  <ol className="relative ml-2 border-l-2 border-teal-500/60">
                    {r.stops.map((s, i) => (
                      <li key={s.name + i} className="relative pb-3 pl-5 text-sm last:pb-0"><span className="absolute -left-[7px] top-1.5 h-3 w-3 rounded-full border-2 border-teal-500 bg-white" />{s.name}</li>
                    ))}
                  </ol>
                  <RouteMap stops={r.stops} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
