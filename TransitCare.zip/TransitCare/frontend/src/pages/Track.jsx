import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Search, MapPin } from 'lucide-react';
import api, { errMsg } from '../api/client';
import { StatusBadge, PriorityBadge, Spinner, ErrorBox } from '../components/ui';
import { fmtDateTime, STATUS_COLORS } from '../utils/constants';

export default function Track() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [input, setInput] = useState(id || '');
  const [state, setState] = useState({ loading: false, error: null, data: null });

  useEffect(() => {
    if (!id) { setState({ loading: false, error: null, data: null }); return; }
    setInput(id);
    setState({ loading: true, error: null, data: null });
    api.get(`/complaints/track/${encodeURIComponent(id)}`)
      .then((r) => setState({ loading: false, error: null, data: r.data.data }))
      .catch((e) => setState({ loading: false, error: errMsg(e), data: null }));
  }, [id]);

  const c = state.data;
  return (
    <div className="mx-auto max-w-3xl px-4 py-14">
      <h1 className="text-3xl font-semibold">Track your complaint</h1>
      <p className="mt-2 text-navy-500">Enter the complaint ID you received when you submitted it (for example TC-1A2B3C4D).</p>
      <form className="mt-6 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (input.trim()) navigate(`/track/${input.trim().toUpperCase()}`); }}>
        <input className="input" placeholder="TC-XXXXXXXX" value={input} onChange={(e) => setInput(e.target.value)} aria-label="Complaint ID" />
        <button className="btn-primary"><Search className="h-4 w-4" /> Track</button>
      </form>

      <div className="mt-8">
        {state.loading && <Spinner label="Looking up your complaint..." />}
        {state.error && <ErrorBox message={state.error} />}
        {c && (
          <div className="card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-navy-800 p-5 text-white">
              <div><p className="text-xs text-navy-200">Complaint ID</p><p className="font-display text-xl font-semibold">{c.complaintId}</p></div>
              <StatusBadge status={c.status} />
            </div>
            <dl className="grid gap-4 p-5 text-sm sm:grid-cols-2">
              <div><dt className="text-navy-500">Category</dt><dd className="font-semibold">{c.category}</dd></div>
              <div><dt className="text-navy-500">Priority</dt><dd><PriorityBadge priority={c.priority} /></dd></div>
              <div><dt className="text-navy-500">Bus</dt><dd className="font-semibold">{c.busNumber}</dd></div>
              <div><dt className="text-navy-500">Route</dt><dd className="font-semibold">{c.route ? `${c.route.routeNumber} - ${c.route.name}` : '-'}</dd></div>
              <div className="sm:col-span-2"><dt className="text-navy-500">Location</dt><dd className="font-semibold"><MapPin className="mr-1 inline h-4 w-4 text-teal-600" />{c.location?.address}</dd></div>
              <div><dt className="text-navy-500">Submitted</dt><dd>{fmtDateTime(c.createdAt)}</dd></div>
              <div><dt className="text-navy-500">Last updated</dt><dd>{fmtDateTime(c.updatedAt)}</dd></div>
              {c.adminRemarks && <div className="rounded-lg bg-teal-50 p-3 sm:col-span-2"><dt className="text-xs font-semibold text-teal-700">Message from the transport authority</dt><dd className="mt-1">{c.adminRemarks}</dd></div>}
            </dl>
            <div className="border-t border-navy-100 p-5">
              <h2 className="mb-4 font-display font-semibold">Progress</h2>
              <ol className="relative ml-2 border-l-2 border-navy-100">
                {[...c.statusHistory].reverse().map((h, i) => (
                  <li key={i} className="relative pb-5 pl-6 last:pb-0">
                    <span className="absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 border-white" style={{ background: STATUS_COLORS[h.status] }} />
                    <p className="text-sm font-semibold">{h.status} <span className="font-normal text-navy-500">- {fmtDateTime(h.at)}</span></p>
                    {h.note && <p className="text-sm text-navy-500">{h.note}</p>}
                  </li>
                ))}
              </ol>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
