import { useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, Pencil, Trash2, Search } from 'lucide-react';
import api, { errMsg } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { PageHeader, Spinner, ErrorBox, EmptyState, Modal, StatusBadge, Field } from '../../components/ui';
import ConfirmModal from '../../components/ConfirmModal';
import { BUS_TYPES, BUS_STATUSES } from '../../utils/constants';

function BusForm({ bus, routes, onClose, onSaved }) {
  const [f, setF] = useState({ busNumber: bus?.busNumber || '', route: bus?.route?._id || '', type: bus?.type || 'Ordinary', capacity: bus?.capacity || 50, driverName: bus?.driverName || '', status: bus?.status || 'Active' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      const body = { ...f, capacity: Number(f.capacity) };
      const { data } = bus ? await api.put(`/buses/${bus._id}`, body) : await api.post('/buses', body);
      toast.success(data.message); onSaved();
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };
  return (
    <Modal title={bus ? 'Edit bus' : 'Add bus'} onClose={onClose}>
      <form onSubmit={save} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Bus number"><input className="input" required value={f.busNumber} onChange={set('busNumber')} /></Field>
          <Field label="Route"><select className="input" required value={f.route} onChange={set('route')}><option value="">Select route</option>{routes.map((r) => <option key={r._id} value={r._id}>{r.routeNumber} - {r.name}</option>)}</select></Field>
          <Field label="Type"><select className="input" value={f.type} onChange={set('type')}>{BUS_TYPES.map((t) => <option key={t}>{t}</option>)}</select></Field>
          <Field label="Capacity"><input type="number" min="1" max="200" className="input" value={f.capacity} onChange={set('capacity')} /></Field>
          <Field label="Driver"><input className="input" value={f.driverName} onChange={set('driverName')} /></Field>
          <Field label="Status"><select className="input" value={f.status} onChange={set('status')}>{BUS_STATUSES.map((t) => <option key={t}>{t}</option>)}</select></Field>
        </div>
        <div className="flex justify-end gap-2"><button type="button" className="btn-outline" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save bus'}</button></div>
      </form>
    </Modal>
  );
}

export default function AdminBuses() {
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState(null); // null | {} (new) | bus
  const [del, setDel] = useState(null);
  const buses = useFetch(() => api.get('/buses', { params: { q } }).then((r) => r.data), [q]);
  const routes = useFetch(() => api.get('/routes').then((r) => r.data));

  const remove = async () => {
    try { const { data } = await api.delete(`/buses/${del._id}`); toast.success(data.message); setDel(null); buses.reload(); } catch (e) { toast.error(errMsg(e)); }
  };

  return (
    <>
      <PageHeader title="Buses" subtitle="Manage the fleet." actions={<button className="btn-primary" onClick={() => setEdit({})}><Plus className="h-4 w-4" /> Add bus</button>} />
      <div className="card overflow-hidden">
        <div className="border-b border-navy-100 p-4"><div className="relative max-w-sm"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-navy-200" /><input className="input pl-9" placeholder="Search bus number or driver" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search buses" /></div></div>
        {buses.loading ? <Spinner /> : buses.error ? <div className="p-4"><ErrorBox message={buses.error} onRetry={buses.reload} /></div> : buses.data.length === 0 ? <EmptyState title="No buses found" /> : (
          <div className="overflow-x-auto"><table className="min-w-full divide-y divide-navy-100">
            <thead className="bg-mist"><tr><th className="th">Bus</th><th className="th">Route</th><th className="th">Type</th><th className="th">Capacity</th><th className="th">Driver</th><th className="th">Status</th><th className="th text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-navy-50">{buses.data.map((b) => (
              <tr key={b._id}><td className="td font-semibold">{b.busNumber}</td><td className="td">{b.route ? `${b.route.routeNumber} - ${b.route.name}` : '-'}</td><td className="td">{b.type}</td><td className="td">{b.capacity}</td><td className="td">{b.driverName || '-'}</td><td className="td"><StatusBadge status={b.status} /></td>
                <td className="td"><div className="flex justify-end gap-1"><button className="btn-outline btn-sm" onClick={() => setEdit(b)} aria-label="Edit"><Pencil className="h-3.5 w-3.5" /></button><button className="btn-outline btn-sm text-red-600" onClick={() => setDel(b)} aria-label="Delete"><Trash2 className="h-3.5 w-3.5" /></button></div></td></tr>
            ))}</tbody></table></div>
        )}
      </div>
      {edit && routes.data && <BusForm bus={edit._id ? edit : null} routes={routes.data} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); buses.reload(); }} />}
      {del && <ConfirmModal title="Delete bus?" message={`Bus ${del.busNumber} will be removed. Existing complaints keep the bus number.`} onConfirm={remove} onClose={() => setDel(null)} />}
    </>
  );
}
