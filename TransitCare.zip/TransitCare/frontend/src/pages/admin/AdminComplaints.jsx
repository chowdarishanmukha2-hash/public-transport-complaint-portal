import { PageHeader } from '../../components/ui';
import ComplaintsPanel from '../../components/ComplaintsPanel';

export default function AdminComplaints() {
  return (
    <>
      <PageHeader title="Complaints" subtitle="Search, filter, update status and review locations." />
      <ComplaintsPanel admin />
    </>
  );
}
