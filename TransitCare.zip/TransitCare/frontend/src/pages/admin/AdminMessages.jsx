import toast from 'react-hot-toast';
import { Trash2, MailOpen } from 'lucide-react';
import api, { errMsg } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { PageHeader, Spinner, ErrorBox, EmptyState } from '../../components/ui';
import { fmtDateTime } from '../../utils/constants';

export default function AdminMessages() {
  const msgs = useFetch(() => api.get('/messages').then((r) => r.data));
  const act = async (fn, ok) => { try { await fn(); toast.success(ok); msgs.reload(); } catch (e) { toast.error(errMsg(e)); } };
  return (
    <>
      <PageHeader title="Messages" subtitle="Submissions from the Contact page." />
      {msgs.loading ? <Spinner /> : msgs.error ? <ErrorBox message={msgs.error} onRetry={msgs.reload} /> : msgs.data.length === 0 ? <div className="card"><EmptyState title="No messages yet" /></div> : (
        <div className="space-y-3">
          {msgs.data.map((m) => (
            <div key={m._id} className={`card p-5 ${m.read ? '' : 'border-l-4 border-l-teal-500'}`}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div><p className="font-semibold">{m.subject}</p><p className="text-sm text-navy-500">{m.name} - <a className="text-teal-600" href={`mailto:${m.email}`}>{m.email}</a> - {fmtDateTime(m.createdAt)}</p></div>
                <div className="flex gap-1">
                  {!m.read && <button className="btn-outline btn-sm" onClick={() => act(() => api.patch(`/messages/${m._id}`, { read: true }), 'Marked as read')}><MailOpen className="h-3.5 w-3.5" /> Mark read</button>}
                  <button className="btn-outline btn-sm text-red-600" aria-label="Delete" onClick={() => act(() => api.delete(`/messages/${m._id}`), 'Message deleted')}><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
              </div>
              <p className="mt-3 whitespace-pre-wrap text-sm text-navy-700">{m.message}</p>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
