import { Link } from 'react-router-dom';
import { Users, Bus, Route as RouteIcon } from 'lucide-react';
import api from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { PageHeader, Spinner, ErrorBox, StatCard } from '../../components/ui';
import StatGrid from '../../components/StatGrid';
import ComplaintMap, { MapLegend } from '../../components/ComplaintMap';
import { fmtDate } from '../../utils/constants';

const Bars = ({ rows, label, value, color = 'bg-teal-500' }) => {
  const max = Math.max(1, ...rows.map((r) => r[value]));
  return (
    <ul className="space-y-2.5">
      {rows.map((r) => (
        <li key={r[label]} className="text-sm">
          <div className="mb-1 flex justify-between"><span>{r[label]}</span><span className="font-semibold">{r[value]}</span></div>
          <div className="h-2 rounded-full bg-navy-50"><div className={`h-2 rounded-full ${color}`} style={{ width: `${(r[value] / max) * 100}%` }} /></div>
        </li>
      ))}
    </ul>
  );
};

export default function AdminOverview() {
  const stats = useFetch(() => api.get('/stats/admin').then((r) => r.data));
  const list = useFetch(() => api.get('/complaints', { params: { limit: 200 } }).then((r) => r.data));
  if (stats.loading) return <Spinner />;
  if (stats.error) return <ErrorBox message={stats.error} onRetry={stats.reload} />;
  const s = stats.data;
  const maxTrend = Math.max(1, ...s.trend.map((t) => t.count));
  const points = (list.data || []).map((c) => ({ id: c.complaintId, lat: c.location?.lat, lng: c.location?.lng, status: c.status, category: c.category, busNumber: c.busNumber, address: c.location?.address, createdAt: c.createdAt, link: `/admin/complaints/${c._id}` }));

  return (
    <>
      <PageHeader title="Admin overview" subtitle="Live figures calculated from the database." actions={<Link to="/admin/complaints" className="btn-primary">Manage complaints</Link>} />
      <StatGrid s={s} />
      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        <StatCard label="Registered users" value={s.users} icon={Users} accent="navy" />
        <StatCard label="Buses" value={s.buses} icon={Bus} accent="navy" />
        <StatCard label="Routes" value={s.routes} icon={RouteIcon} accent="navy" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h2 className="mb-4 font-display font-semibold">Complaints per day (last 14 days)</h2>
          <div className="flex h-40 items-end gap-1.5" role="img" aria-label="Bar chart of complaints per day">
            {s.trend.map((t) => (
              <div key={t.date} className="group flex flex-1 flex-col items-center justify-end" title={`${fmtDate(t.date)}: ${t.count}`}>
                <span className="mb-1 text-[10px] text-navy-500">{t.count || ''}</span>
                <div className="w-full rounded-t bg-teal-500" style={{ height: `${Math.max(3, (t.count / maxTrend) * 100)}%`, opacity: t.count ? 1 : 0.25 }} />
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-xs text-navy-500"><span>{fmtDate(s.trend[0].date)}</span><span>{fmtDate(s.trend[s.trend.length - 1].date)}</span></div>
        </div>
        <div className="card p-5">
          <h2 className="mb-4 font-display font-semibold">By category</h2>
          {s.byCategory.length ? <Bars rows={s.byCategory} label="category" value="count" /> : <p className="text-sm text-navy-500">No data yet.</p>}
        </div>
        <div className="card p-5">
          <h2 className="mb-4 font-display font-semibold">Routes with most complaints</h2>
          {s.topRoutes.length ? <Bars rows={s.topRoutes.map((r) => ({ ...r, name: `${r.routeNumber} - ${r.name}` }))} label="name" value="count" color="bg-navy-600" /> : <p className="text-sm text-navy-500">No data yet.</p>}
        </div>
        <div className="card p-5">
          <h2 className="mb-4 font-display font-semibold">By priority</h2>
          {s.byPriority.length ? <Bars rows={['Critical', 'High', 'Medium', 'Low'].map((p) => ({ priority: p, count: s.byPriority.find((x) => x.priority === p)?.count || 0 }))} label="priority" value="count" color="bg-amber-500" /> : <p className="text-sm text-navy-500">No data yet.</p>}
        </div>
      </div>

      <div className="card mt-6 p-5">
        <h2 className="mb-3 font-display font-semibold">Complaint locations</h2>
        {list.loading ? <Spinner /> : <><ComplaintMap points={points} height="h-[26rem]" /><MapLegend /></>}
      </div>
    </>
  );
}
