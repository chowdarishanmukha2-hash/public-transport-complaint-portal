import { useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, Pencil, Trash2, Search } from 'lucide-react';
import api, { errMsg } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { PageHeader, Spinner, ErrorBox, EmptyState, Modal, StatusBadge, Field } from '../../components/ui';
import ConfirmModal from '../../components/ConfirmModal';

const stopsToText = (stops = []) => stops.map((s) => [s.name, s.lat ?? '', s.lng ?? ''].join(', ').replace(/(, )+$/, '')).join('\n');
const textToStops = (t) => t.split('\n').map((l) => l.trim()).filter(Boolean).map((l) => {
  const [name, lat, lng] = l.split(',').map((x) => x.trim());
  const s = { name };
  if (lat && lng && !isNaN(lat) && !isNaN(lng)) { s.lat = Number(lat); s.lng = Number(lng); }
  return s;
});

function RouteForm({ route, onClose, onSaved }) {
  const [f, setF] = useState({
    routeNumber: route?.routeNumber || '', name: route?.name || '', origin: route?.origin || '', destination: route?.destination || '',
    distanceKm: route?.distanceKm ?? 0, frequencyMins: route?.frequencyMins ?? 15, firstBus: route?.firstBus || '05:30', lastBus: route?.lastBus || '23:00',
    active: route?.active ?? true, stops: stopsToText(route?.stops),
  });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      const body = { ...f, distanceKm: Number(f.distanceKm), frequencyMins: Number(f.frequencyMins), stops: textToStops(f.stops) };
      const { data } = route ? await api.put(`/routes/${route._id}`, body) : await api.post('/routes', body);
      toast.success(data.message); onSaved();
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };
  return (
    <Modal title={route ? 'Edit route' : 'Add route'} onClose={onClose} wide>
      <form onSubmit={save} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Route number"><input className="input" required value={f.routeNumber} onChange={set('routeNumber')} /></Field>
          <div className="sm:col-span-2"><Field label="Route name"><input className="input" required value={f.name} onChange={set('name')} /></Field></div>
          <Field label="Origin"><input className="input" required value={f.origin} onChange={set('origin')} /></Field>
          <Field label="Destination"><input className="input" required value={f.destination} onChange={set('destination')} /></Field>
          <Field label="Distance (km)"><input type="number" min="0" step="0.1" className="input" value={f.distanceKm} onChange={set('distanceKm')} /></Field>
          <Field label="Frequency (minutes)"><input type="number" min="1" className="input" value={f.frequencyMins} onChange={set('frequencyMins')} /></Field>
          <Field label="First bus"><input type="time" className="input" value={f.firstBus} onChange={set('firstBus')} /></Field>
          <Field label="Last bus"><input type="time" className="input" value={f.lastBus} onChange={set('lastBus')} /></Field>
          <Field label="Status"><select className="input" value={String(f.active)} onChange={(e) => setF({ ...f, active: e.target.value === 'true' })}><option value="true">Active</option><option value="false">Inactive</option></select></Field>
        </div>
        <Field label="Stops" hint="One per line: name, latitude, longitude (coordinates optional)">
          <textarea className="input min-h-[140px] font-mono text-xs" value={f.stops} onChange={set('stops')} placeholder={'Ameerpet, 17.4375, 78.4483\nBegumpet'} />
        </Field>
        <div className="flex justify-end gap-2"><button type="button" className="btn-outline" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save route'}</button></div>
      </form>
    </Modal>
  );
}

export default function AdminRoutes() {
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const routes = useFetch(() => api.get('/routes', { params: { q } }).then((r) => r.data), [q]);
  const remove = async () => {
    try { const { data } = await api.delete(`/routes/${del._id}`); toast.success(data.message); setDel(null); routes.reload(); }
    catch (e) { toast.error(errMsg(e)); setDel(null); }
  };
  return (
    <>
      <PageHeader title="Routes" subtitle="Manage routes and stops." actions={<button className="btn-primary" onClick={() => setEdit({})}><Plus className="h-4 w-4" /> Add route</button>} />
      <div className="card overflow-hidden">
        <div className="border-b border-navy-100 p-4"><div className="relative max-w-sm"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-navy-200" /><input className="input pl-9" placeholder="Search routes" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search routes" /></div></div>
        {routes.loading ? <Spinner /> : routes.error ? <div className="p-4"><ErrorBox message={routes.error} onRetry={routes.reload} /></div> : routes.data.length === 0 ? <EmptyState title="No routes found" /> : (
          <div className="overflow-x-auto"><table className="min-w-full divide-y divide-navy-100">
            <thead className="bg-mist"><tr><th className="th">No.</th><th className="th">Name</th><th className="th">Stops</th><th className="th">Distance</th><th className="th">Frequency</th><th className="th">Timing</th><th className="th">Status</th><th className="th text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-navy-50">{routes.data.map((r) => (
              <tr key={r._id}><td className="td font-semibold">{r.routeNumber}</td><td className="td">{r.name}</td><td className="td">{r.stops.length}</td><td className="td">{r.distanceKm} km</td><td className="td">{r.frequencyMins} min</td><td className="td whitespace-nowrap">{r.firstBus} - {r.lastBus}</td><td className="td"><StatusBadge status={r.active ? 'Active' : 'Inactive'} /></td>
                <td className="td"><div className="flex justify-end gap-1"><button className="btn-outline btn-sm" onClick={() => setEdit(r)} aria-label="Edit"><Pencil className="h-3.5 w-3.5" /></button><button className="btn-outline btn-sm text-red-600" onClick={() => setDel(r)} aria-label="Delete"><Trash2 className="h-3.5 w-3.5" /></button></div></td></tr>
            ))}</tbody></table></div>
        )}
      </div>
      {edit && <RouteForm route={edit._id ? edit : null} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); routes.reload(); }} />}
      {del && <ConfirmModal title="Delete route?" message={`Route ${del.routeNumber} will be removed. Routes with buses or complaints cannot be deleted; mark them inactive instead.`} onConfirm={remove} onClose={() => setDel(null)} />}
    </>
  );
}
