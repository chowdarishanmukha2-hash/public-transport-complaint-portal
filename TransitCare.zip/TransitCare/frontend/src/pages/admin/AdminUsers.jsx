import { useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, Pencil, Trash2, Search } from 'lucide-react';
import api, { errMsg } from '../../api/client';
import useFetch from '../../hooks/useFetch';
import { useAuth } from '../../context/AuthContext';
import { PageHeader, Spinner, ErrorBox, EmptyState, Modal, StatusBadge, Field } from '../../components/ui';
import ConfirmModal from '../../components/ConfirmModal';
import { fmtDate } from '../../utils/constants';

function UserForm({ user, onClose, onSaved }) {
  const [f, setF] = useState({ name: user?.name || '', email: user?.email || '', phone: user?.phone || '', role: user?.role || 'passenger', active: user?.active ?? true, password: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async (e) => {
    e.preventDefault(); setBusy(true);
    try {
      const body = { name: f.name, phone: f.phone, role: f.role, active: f.active, ...(f.password ? { password: f.password } : {}) };
      const { data } = user ? await api.put(`/users/${user._id}`, body) : await api.post('/users', { ...body, email: f.email, password: f.password });
      toast.success(data.message); onSaved();
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };
  return (
    <Modal title={user ? 'Edit user' : 'Add user'} onClose={onClose}>
      <form onSubmit={save} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Name"><input className="input" required value={f.name} onChange={set('name')} /></Field>
          <Field label="Email"><input type="email" className="input" required disabled={!!user} value={f.email} onChange={set('email')} /></Field>
          <Field label="Phone"><input className="input" value={f.phone} onChange={set('phone')} /></Field>
          <Field label="Role"><select className="input" value={f.role} onChange={set('role')}><option value="passenger">Passenger</option><option value="admin">Admin</option></select></Field>
          <Field label="Account"><select className="input" value={String(f.active)} onChange={(e) => setF({ ...f, active: e.target.value === 'true' })}><option value="true">Active</option><option value="false">Deactivated</option></select></Field>
          <Field label={user ? 'New password (optional)' : 'Password'}><input type="password" className="input" required={!user} minLength={8} autoComplete="new-password" value={f.password} onChange={set('password')} /></Field>
        </div>
        <div className="flex justify-end gap-2"><button type="button" className="btn-outline" onClick={onClose}>Cancel</button><button className="btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save user'}</button></div>
      </form>
    </Modal>
  );
}

export default function AdminUsers() {
  const { user: me } = useAuth();
  const [q, setQ] = useState('');
  const [role, setRole] = useState('');
  const [edit, setEdit] = useState(null);
  const [del, setDel] = useState(null);
  const users = useFetch(() => api.get('/users', { params: { q, role } }).then((r) => r.data), [q, role]);
  const remove = async () => {
    try { const { data } = await api.delete(`/users/${del._id}`); toast.success(data.message); setDel(null); users.reload(); }
    catch (e) { toast.error(errMsg(e)); setDel(null); }
  };
  return (
    <>
      <PageHeader title="Users" subtitle="Manage passengers and administrators." actions={<button className="btn-primary" onClick={() => setEdit({})}><Plus className="h-4 w-4" /> Add user</button>} />
      <div className="card overflow-hidden">
        <div className="grid gap-3 border-b border-navy-100 p-4 sm:grid-cols-3 lg:max-w-2xl">
          <div className="relative sm:col-span-2"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-navy-200" /><input className="input pl-9" placeholder="Search name or email" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search users" /></div>
          <select className="input" value={role} onChange={(e) => setRole(e.target.value)} aria-label="Role"><option value="">All roles</option><option value="passenger">Passengers</option><option value="admin">Admins</option></select>
        </div>
        {users.loading ? <Spinner /> : users.error ? <div className="p-4"><ErrorBox message={users.error} onRetry={users.reload} /></div> : users.data.length === 0 ? <EmptyState title="No users found" /> : (
          <div className="overflow-x-auto"><table className="min-w-full divide-y divide-navy-100">
            <thead className="bg-mist"><tr><th className="th">Name</th><th className="th">Email</th><th className="th">Role</th><th className="th">Complaints</th><th className="th">Joined</th><th className="th">Status</th><th className="th text-right">Actions</th></tr></thead>
            <tbody className="divide-y divide-navy-50">{users.data.map((u) => (
              <tr key={u._id}><td className="td font-semibold">{u.name}{u._id === me._id && <span className="ml-2 text-xs font-normal text-navy-500">(you)</span>}</td><td className="td">{u.email}</td><td className="td capitalize">{u.role}</td><td className="td">{u.complaintCount}</td><td className="td whitespace-nowrap">{fmtDate(u.createdAt)}</td><td className="td"><StatusBadge status={u.active ? 'Active' : 'Inactive'} /></td>
                <td className="td"><div className="flex justify-end gap-1"><button className="btn-outline btn-sm" onClick={() => setEdit(u)} aria-label="Edit"><Pencil className="h-3.5 w-3.5" /></button>{u._id !== me._id && <button className="btn-outline btn-sm text-red-600" onClick={() => setDel(u)} aria-label="Delete"><Trash2 className="h-3.5 w-3.5" /></button>}</div></td></tr>
            ))}</tbody></table></div>
        )}
      </div>
      {edit && <UserForm user={edit._id ? edit : null} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); users.reload(); }} />}
      {del && <ConfirmModal title="Delete user?" message={`${del.name} and all ${del.complaintCount} of their complaints will be permanently deleted. To keep the records, deactivate the account instead.`} onConfirm={remove} onClose={() => setDel(null)} />}
    </>
  );
}
