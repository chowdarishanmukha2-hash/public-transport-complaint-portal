export const CATEGORIES = ['Bus delay', 'Overcrowding', 'Driver behaviour', 'Conductor behaviour', 'Vehicle cleanliness', 'Damaged bus', 'Missed stop', 'Route issue', 'Other'];
export const STATUSES = ['Pending', 'In Progress', 'Resolved', 'Rejected'];
export const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];
export const BUS_TYPES = ['Ordinary', 'Express', 'AC', 'Electric'];
export const BUS_STATUSES = ['Active', 'Maintenance', 'Inactive'];
export const STATUS_COLORS = { Pending: '#F59E0B', 'In Progress': '#3B82F6', Resolved: '#12A8A0', Rejected: '#DC2626' };
export const MAP_CENTER = [17.4, 78.45]; // Hyderabad demo city

export const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-');
export const fmtDateTime = (d) => (d ? new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '-');
export const timeAgo = (d) => {
  const s = Math.max(1, Math.floor((Date.now() - new Date(d).getTime()) / 1000));
  if (s < 3600) return `${Math.floor(s / 60) || 1} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
};
