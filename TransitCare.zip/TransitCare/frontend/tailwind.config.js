/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: { 50: '#EEF2F8', 100: '#D6DFEE', 200: '#AEBFDC', 500: '#2F5188', 600: '#1D4477', 700: '#13315C', 800: '#0B2545', 900: '#071A33' },
        teal: { 50: '#E8F8F7', 100: '#C6EEEB', 200: '#93DDD8', 400: '#2DC4BC', 500: '#12A8A0', 600: '#0D8A84', 700: '#0A6D69' },
        mist: '#F3F7FA',
      },
      fontFamily: {
        display: ['Sora', 'system-ui', 'sans-serif'],
        sans: ['"Public Sans"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
